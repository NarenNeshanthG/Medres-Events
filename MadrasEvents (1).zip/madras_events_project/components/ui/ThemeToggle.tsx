"use client";

import { motion } from "motion/react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/components/providers/ThemeProvider";

export function ThemeToggle({ className }: { className?: string }) {
  const { theme, toggleTheme } = useTheme();

  return (
    <motion.button
      onClick={toggleTheme}
      whileTap={{ scale: 0.92 }}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      className={`relative grid h-9 w-9 place-items-center rounded-full transition-colors ${className ?? ""}`}
      style={{ border: "1px solid var(--border)", color: "var(--ink-muted)" }}
    >
      <motion.span
        key={theme}
        initial={{ rotate: -30, opacity: 0, scale: 0.6 }}
        animate={{ rotate: 0, opacity: 1, scale: 1 }}
        exit={{ rotate: 30, opacity: 0, scale: 0.6 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="absolute"
      >
        {theme === "dark" ? (
          <Sun size={16} style={{ color: "var(--gold)" }} />
        ) : (
          <Moon size={16} style={{ color: "var(--gold-dark)" }} />
        )}
      </motion.span>
    </motion.button>
  );
}
