"use client";

import {
  Target, Eye, Sparkles,
  Code2, Building2, Rocket, ShoppingCart, LayoutDashboard, PenTool, RefreshCw,
  Search, Wrench, Bot, MessageSquare, Server, Network, Plug,
  Zap, Smartphone, ShieldCheck, TrendingUp, Headphones, Cpu,
  AtSign, Link2, Rss, Globe,
  ArrowRight, ArrowUp, ArrowUpRight, Menu, X, Check, Star,
  Mail, Phone, MapPin, Send, ChevronDown, Loader2, type LucideIcon,
} from "lucide-react";

/**
 * Map of string keys (used in lib/data.ts) to Lucide icon components.
 * Note: lucide-react v1+ removed brand icons; we use generic alternatives
 * for social links and map the old names here for convenience.
 */
const ICONS: Record<string, LucideIcon> = {
  Target, Eye, Sparkles,
  Code2, Building2, Rocket, ShoppingCart, LayoutDashboard, PenTool, RefreshCw,
  Search, Wrench, Bot, MessageSquare, Server, Network, Plug,
  Zap, Smartphone, ShieldCheck, TrendingUp, Headphones, Cpu,
  // Social icon aliases (brand icons were removed from lucide-react)
  Twitter: AtSign,
  Linkedin: Link2,
  Github: Globe,
  Instagram: Rss,
  ArrowRight, ArrowUp, ArrowUpRight, Menu, X, Check, Star,
  Mail, Phone, MapPin, Send, ChevronDown, Loader2, Globe,
};

export function dynamicIconImport(name: string): LucideIcon | undefined {
  return ICONS[name];
}
