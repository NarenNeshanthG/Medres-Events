"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ChevronRight, ChevronLeft, Check, Minus, Plus, CalendarDays, MapPin, User, Phone, Mail, FileText, Clock, Package } from "lucide-react";
import { useBooking } from "./BookingContext";
import { SERVICES, CUSTOM_ADDONS, STANDARD_PACKAGE, EVENT_TYPES } from "@/lib/data";
import {
  INITIAL_BOOKING_FORM,
  calculateAddonTotal,
  calculatePackageTotal,
  validateBookingStep,
  formatINR,
} from "@/lib/booking";
import type { BookingFormData } from "@/lib/types";

const STEPS = ["Service", "Event Details", "Your Details", "Confirm"];

export function BookingModal() {
  const { isOpen, initialService, initialPackage, closeBooking } = useBooking();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<BookingFormData>(INITIAL_BOOKING_FORM);
  const [errors, setErrors] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const overlayRef = useRef<HTMLDivElement>(null);

  // Reset & populate form when modal opens
  useEffect(() => {
    if (isOpen) {
      setStep(1);
      setErrors([]);
      setSubmitted(false);
      setForm({
        ...INITIAL_BOOKING_FORM,
        selectedService: initialService,
        selectedPackage: initialPackage,
      });
    }
  }, [isOpen, initialService, initialPackage]);

  // ESC key close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") closeBooking(); };
    if (isOpen) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [isOpen, closeBooking]);

  const update = (key: keyof BookingFormData, value: string | Record<string, number>) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const updateAddon = (id: string, qty: number) =>
    setForm((prev) => ({
      ...prev,
      customAddons: { ...prev.customAddons, [id]: Math.max(0, qty) },
    }));

  const next = () => {
    const errs = validateBookingStep(step, form);
    if (errs.length) { setErrors(errs); return; }
    setErrors([]);
    setStep((s) => Math.min(s + 1, STEPS.length));
  };

  const prev = () => { setErrors([]); setStep((s) => Math.max(s - 1, 1)); };

  const submit = () => {
    setSubmitted(true);
  };

  const { total, hasVariablePrice } = calculateAddonTotal(form.customAddons);
  const pricing = calculatePackageTotal(form.selectedPackage, form.customAddons);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={overlayRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)" }}
          onClick={(e) => { if (e.target === overlayRef.current) closeBooking(); }}
        >
          <motion.div
            initial={{ scale: 0.92, opacity: 0, y: 24 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.92, opacity: 0, y: 24 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-2xl max-h-[90vh] overflow-hidden rounded-2xl"
            style={{ background: "var(--bg)", border: "1px solid var(--border)" }}
            role="dialog"
            aria-modal="true"
            aria-label="Event Booking"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
              <div>
                <h2 className="font-display text-xl font-bold" style={{ color: "var(--ink)" }}>
                  Book Your Event
                </h2>
                <p className="text-xs mt-0.5" style={{ color: "var(--ink-muted)" }}>
                  Step {step} of {STEPS.length} — {STEPS[step - 1]}
                </p>
              </div>
              <button
                onClick={closeBooking}
                aria-label="Close booking"
                className="grid h-9 w-9 place-items-center rounded-full transition-colors"
                style={{ border: "1px solid var(--border)", color: "var(--ink-muted)" }}
              >
                <X size={16} />
              </button>
            </div>

            {/* Step progress */}
            <div className="flex gap-1 px-6 pt-4">
              {STEPS.map((s, i) => (
                <div key={s} className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "var(--border)" }}>
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: "var(--gold)" }}
                    initial={{ width: 0 }}
                    animate={{ width: step > i ? "100%" : "0%" }}
                    transition={{ duration: 0.4, ease: "easeOut" }}
                  />
                </div>
              ))}
            </div>

            {/* Body */}
            <div className="overflow-y-auto px-6 pb-6 pt-4" style={{ maxHeight: "calc(90vh - 180px)" }}>
              <AnimatePresence mode="wait">
                {!submitted ? (
                  <motion.div
                    key={step}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.25 }}
                  >
                    {step === 1 && <Step1 form={form} update={update} />}
                    {step === 2 && <Step2 form={form} update={update} updateAddon={updateAddon} />}
                    {step === 3 && <Step3 form={form} update={update} />}
                    {step === 4 && <Step4 form={form} pricing={pricing} />}
                  </motion.div>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center justify-center py-12 text-center"
                  >
                    <div
                      className="mb-6 grid h-20 w-20 place-items-center rounded-full"
                      style={{ background: "var(--gold-glow)", border: "2px solid var(--gold)" }}
                    >
                      <Check size={36} style={{ color: "var(--gold)" }} />
                    </div>
                    <h3 className="font-display text-2xl font-bold mb-2" style={{ color: "var(--ink)" }}>
                      Booking Request Received!
                    </h3>
                    <p className="text-sm leading-relaxed max-w-sm" style={{ color: "var(--ink-muted)" }}>
                      Thank you, <strong style={{ color: "var(--ink)" }}>{form.customerName}</strong>! Our team will contact you at{" "}
                      <strong style={{ color: "var(--gold)" }}>{form.customerPhone}</strong> within 24 hours to confirm your event details and send a formal proposal.
                    </p>
                    <div className="mt-6 p-4 rounded-xl text-sm" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
                      <p style={{ color: "var(--ink-muted)" }}>Reference: <strong style={{ color: "var(--gold)" }}>ME-{Date.now().toString().slice(-6)}</strong></p>
                    </div>
                    <button
                      onClick={closeBooking}
                      className="mt-6 rounded-full px-8 py-3 text-sm font-semibold btn-gold"
                    >
                      Close
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Errors */}
              {errors.length > 0 && (
                <div className="mt-4 rounded-xl p-3 text-sm" style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#ef4444" }}>
                  {errors.map((e, i) => <p key={i}>• {e}</p>)}
                </div>
              )}
            </div>

            {/* Footer nav */}
            {!submitted && (
              <div
                className="flex items-center justify-between px-6 py-4"
                style={{ borderTop: "1px solid var(--border)" }}
              >
                <button
                  onClick={prev}
                  disabled={step === 1}
                  className="flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium transition-all disabled:opacity-40"
                  style={{ border: "1px solid var(--border)", color: "var(--ink-muted)" }}
                >
                  <ChevronLeft size={16} /> Back
                </button>

                {step < STEPS.length ? (
                  <button
                    onClick={next}
                    className="btn-gold flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold text-white"
                  >
                    Next <ChevronRight size={16} />
                  </button>
                ) : (
                  <button
                    onClick={submit}
                    className="btn-gold flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold text-white"
                  >
                    Confirm Booking <Check size={16} />
                  </button>
                )}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ─── Step 1: Service Selection ─── */
function Step1({ form, update }: { form: BookingFormData; update: (k: keyof BookingFormData, v: string) => void }) {
  const packages = [
    { id: "standard", label: "Standard Package", sub: `₹49,999 — All-inclusive`, icon: Package },
    { id: "custom", label: "Custom Package", sub: "Build your own package", icon: Package },
  ];

  return (
    <div>
      <h3 className="font-display text-lg font-semibold mb-1" style={{ color: "var(--ink)" }}>What are you booking?</h3>
      <p className="text-sm mb-4" style={{ color: "var(--ink-muted)" }}>Select a package or a specific service</p>

      <div className="grid grid-cols-2 gap-3 mb-5">
        {packages.map((pkg) => (
          <button
            key={pkg.id}
            onClick={() => update("selectedPackage", pkg.id as "standard" | "custom")}
            className="rounded-xl p-4 text-left transition-all"
            style={{
              background: form.selectedPackage === pkg.id ? "var(--gold-glow)" : "var(--bg-2)",
              border: `2px solid ${form.selectedPackage === pkg.id ? "var(--gold)" : "var(--border)"}`,
              color: "var(--ink)",
            }}
          >
            <Package size={20} style={{ color: "var(--gold)", marginBottom: 8 }} />
            <p className="text-sm font-semibold">{pkg.label}</p>
            <p className="text-xs mt-1" style={{ color: "var(--ink-muted)" }}>{pkg.sub}</p>
          </button>
        ))}
      </div>

      <p className="text-xs font-medium mb-3 uppercase tracking-wider" style={{ color: "var(--ink-faint)" }}>Or book a specific service</p>
      <div className="grid grid-cols-1 gap-2 max-h-52 overflow-y-auto pr-1">
        {SERVICES.map((svc) => (
          <button
            key={svc.id}
            onClick={() => { update("selectedService", svc.title); update("selectedPackage", "service"); }}
            className="flex items-center gap-3 rounded-xl px-4 py-3 text-left transition-all"
            style={{
              background: form.selectedService === svc.title ? "var(--gold-glow)" : "var(--bg-2)",
              border: `1px solid ${form.selectedService === svc.title ? "var(--gold)" : "var(--border)"}`,
              color: "var(--ink)",
            }}
          >
            <span className="text-xs font-medium" style={{ color: "var(--gold)" }}>{svc.price}</span>
            <span className="text-sm font-medium flex-1">{svc.title}</span>
            {form.selectedService === svc.title && <Check size={14} style={{ color: "var(--gold)" }} />}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ─── Step 2: Event Details ─── */
function Step2({
  form,
  update,
  updateAddon,
}: {
  form: BookingFormData;
  update: (k: keyof BookingFormData, v: string) => void;
  updateAddon: (id: string, qty: number) => void;
}) {
  return (
    <div className="space-y-4">
      <h3 className="font-display text-lg font-semibold mb-1" style={{ color: "var(--ink)" }}>Event Details</h3>

      <div className="grid grid-cols-2 gap-3">
        <FormField icon={CalendarDays} label="Event Date *">
          <input
            type="date"
            value={form.eventDate}
            min={new Date().toISOString().split("T")[0]}
            onChange={(e) => update("eventDate", e.target.value)}
            className="booking-input"
          />
        </FormField>
        <FormField icon={Clock} label="Event Time *">
          <input
            type="time"
            value={form.eventTime}
            onChange={(e) => update("eventTime", e.target.value)}
            className="booking-input"
          />
        </FormField>
      </div>

      <FormField icon={MapPin} label="Event Location *">
        <input
          type="text"
          placeholder="e.g. Grand Hyatt, Chennai"
          value={form.eventLocation}
          onChange={(e) => update("eventLocation", e.target.value)}
          className="booking-input"
        />
      </FormField>

      <FormField icon={Package} label="Event Type *">
        <select
          value={form.eventType}
          onChange={(e) => update("eventType", e.target.value)}
          className="booking-input"
        >
          <option value="">Select event type...</option>
          {EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </FormField>

      {/* Add-ons for custom package */}
      {form.selectedPackage === "custom" && (
        <div>
          <p className="text-sm font-semibold mb-3" style={{ color: "var(--ink)" }}>Select Add-ons</p>
          <div className="space-y-2">
            {CUSTOM_ADDONS.map((addon) => {
              const qty = form.customAddons[addon.id] ?? 0;
              return (
                <div
                  key={addon.id}
                  className="flex items-center gap-3 rounded-xl px-4 py-3"
                  style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: "var(--ink)" }}>{addon.name}</p>
                    <p className="text-xs mt-0.5" style={{ color: "var(--ink-muted)" }}>
                      {addon.pricePerUnit === null
                        ? "Price on inquiry"
                        : `${formatINR(addon.pricePerUnit)} / ${addon.unit} · Min ${addon.minQty}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateAddon(addon.id, qty - 1)}
                      disabled={qty === 0}
                      className="grid h-7 w-7 place-items-center rounded-full transition-colors disabled:opacity-30"
                      style={{ border: "1px solid var(--border)", color: "var(--ink)" }}
                    >
                      <Minus size={12} />
                    </button>
                    <span className="w-6 text-center text-sm font-semibold" style={{ color: "var(--ink)" }}>{qty}</span>
                    <button
                      onClick={() => updateAddon(addon.id, qty < addon.minQty ? addon.minQty : qty + 1)}
                      className="grid h-7 w-7 place-items-center rounded-full transition-colors"
                      style={{ border: "1px solid var(--gold)", color: "var(--gold)" }}
                    >
                      <Plus size={12} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Step 3: Customer Details ─── */
function Step3({ form, update }: { form: BookingFormData; update: (k: keyof BookingFormData, v: string) => void }) {
  return (
    <div className="space-y-4">
      <h3 className="font-display text-lg font-semibold mb-1" style={{ color: "var(--ink)" }}>Your Details</h3>

      <FormField icon={User} label="Full Name *">
        <input
          type="text"
          placeholder="e.g. Priya Sharma"
          value={form.customerName}
          onChange={(e) => update("customerName", e.target.value)}
          className="booking-input"
        />
      </FormField>
      <div className="grid grid-cols-2 gap-3">
        <FormField icon={Phone} label="Phone Number *">
          <input
            type="tel"
            placeholder="+91 98765 43210"
            value={form.customerPhone}
            onChange={(e) => update("customerPhone", e.target.value)}
            className="booking-input"
          />
        </FormField>
        <FormField icon={Mail} label="Email Address *">
          <input
            type="email"
            placeholder="you@email.com"
            value={form.customerEmail}
            onChange={(e) => update("customerEmail", e.target.value)}
            className="booking-input"
          />
        </FormField>
      </div>
      <FormField icon={FileText} label="Special Requirements">
        <textarea
          placeholder="Any special requests, themes, dietary requirements..."
          value={form.specialRequirements}
          onChange={(e) => update("specialRequirements", e.target.value)}
          rows={3}
          className="booking-input resize-none"
        />
      </FormField>
    </div>
  );
}

/* ─── Step 4: Summary ─── */
function Step4({ form, pricing }: { form: BookingFormData; pricing: ReturnType<typeof calculatePackageTotal> }) {
  const { lineItems, hasVariablePrice } = calculateAddonTotal(form.customAddons);
  const rows: { label: string; value: string }[] = [
    { label: "Name", value: form.customerName },
    { label: "Phone", value: form.customerPhone },
    { label: "Email", value: form.customerEmail },
    { label: "Event Date", value: form.eventDate ? new Date(form.eventDate).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : "—" },
    { label: "Event Time", value: form.eventTime || "—" },
    { label: "Location", value: form.eventLocation || "—" },
    { label: "Event Type", value: form.eventType || "—" },
  ];

  return (
    <div>
      <h3 className="font-display text-lg font-semibold mb-4" style={{ color: "var(--ink)" }}>Booking Summary</h3>

      {/* Service / Package */}
      <div className="rounded-xl p-4 mb-4" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
        <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--ink-faint)" }}>Selected</p>
        {form.selectedPackage === "standard" && (
          <p className="text-sm font-semibold" style={{ color: "var(--ink)" }}>Standard Package — {formatINR(49999)}</p>
        )}
        {form.selectedPackage === "custom" && (
          <p className="text-sm font-semibold" style={{ color: "var(--ink)" }}>Custom Package</p>
        )}
        {form.selectedPackage === "service" && form.selectedService && (
          <p className="text-sm font-semibold" style={{ color: "var(--ink)" }}>{form.selectedService}</p>
        )}

        {/* Addon line items */}
        {lineItems.length > 0 && (
          <div className="mt-3 space-y-1.5 pt-3" style={{ borderTop: "1px solid var(--border)" }}>
            {lineItems.map((item) => (
              <div key={item.name} className="flex justify-between text-xs" style={{ color: "var(--ink-muted)" }}>
                <span>{item.name} × {item.qty}</span>
                <span>{formatINR(item.subtotal)}</span>
              </div>
            ))}
            {hasVariablePrice && (
              <p className="text-xs italic" style={{ color: "var(--gold)" }}>+ Flower Decoration (price on inquiry)</p>
            )}
          </div>
        )}

        {/* Total */}
        {(pricing.total > 0 || pricing.hasVariablePrice) && (
          <div className="mt-3 pt-3 flex justify-between" style={{ borderTop: "1px solid var(--border)" }}>
            <span className="text-sm font-semibold" style={{ color: "var(--ink)" }}>Estimated Total</span>
            <span className="text-sm font-bold" style={{ color: "var(--gold)" }}>
              {pricing.hasVariablePrice && pricing.total === 0 ? "On Inquiry" : formatINR(pricing.total)}
              {pricing.hasVariablePrice && pricing.total > 0 && " + Inquiry"}
            </span>
          </div>
        )}
      </div>

      {/* Details grid */}
      <div className="rounded-xl p-4 space-y-2.5" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
        <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: "var(--ink-faint)" }}>Your Details</p>
        {rows.map(({ label, value }) => (
          <div key={label} className="flex justify-between gap-4 text-sm">
            <span style={{ color: "var(--ink-muted)" }}>{label}</span>
            <span className="text-right font-medium" style={{ color: "var(--ink)" }}>{value}</span>
          </div>
        ))}
        {form.specialRequirements && (
          <div className="pt-2" style={{ borderTop: "1px solid var(--border)" }}>
            <p className="text-xs" style={{ color: "var(--ink-muted)" }}>Special Requirements:</p>
            <p className="text-xs mt-1" style={{ color: "var(--ink)" }}>{form.specialRequirements}</p>
          </div>
        )}
      </div>

      <p className="mt-4 text-xs text-center" style={{ color: "var(--ink-faint)" }}>
        By confirming, you agree that our team will contact you within 24 hours. A 25% advance secures your booking.
      </p>
    </div>
  );
}

/* ─── Shared form field wrapper ─── */
function FormField({ icon: Icon, label, children }: { icon: React.FC<{size?: number; style?: React.CSSProperties}>; label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="flex items-center gap-1.5 text-xs font-medium mb-1.5" style={{ color: "var(--ink-muted)" }}>
        <Icon size={12} style={{ color: "var(--gold)" }} /> {label}
      </label>
      {children}
      <style jsx global>{`
        .booking-input {
          width: 100%;
          padding: 10px 14px;
          border-radius: 10px;
          font-size: 14px;
          background: var(--bg-3);
          color: var(--ink);
          border: 1px solid var(--border);
          outline: none;
          transition: border-color 0.2s;
        }
        .booking-input:focus {
          border-color: var(--gold);
        }
        .booking-input option {
          background: var(--bg-3);
          color: var(--ink);
        }
      `}</style>
    </div>
  );
}
