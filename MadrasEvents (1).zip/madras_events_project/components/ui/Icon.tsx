"use client";

import type { CSSProperties } from "react";
import { dynamicIconImport } from "./iconMap";

/**
 * Renders a Lucide icon by string name. Client component because Lucide's
 * dynamic import map must be resolved at runtime.
 */
export function Icon({
  name,
  className,
  size = 24,
  strokeWidth = 1.75,
  style,
}: {
  name: string;
  className?: string;
  size?: number;
  strokeWidth?: number;
  style?: CSSProperties;
}) {
  const Cmp = dynamicIconImport(name);
  if (!Cmp) return null;
  return <Cmp className={className} size={size} strokeWidth={strokeWidth} style={style} />;
}
