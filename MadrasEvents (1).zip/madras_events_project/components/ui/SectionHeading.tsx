import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface SectionHeadingProps {
  label?: string;
  title: ReactNode;
  description?: string;
  className?: string;
  align?: "center" | "left";
}

export function SectionHeading({
  label,
  title,
  description,
  className,
  align = "center",
}: SectionHeadingProps) {
  const isCenter = align === "center";

  return (
    <div className={cn("mb-14", isCenter && "text-center mx-auto max-w-2xl", className)}>
      {label && (
        <div
          className={cn(
            "mb-4 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-widest",
            isCenter && "mx-auto"
          )}
          style={{
            border: "1px solid var(--border-strong)",
            color: "var(--gold)",
            background: "var(--gold-glow)",
          }}
        >
          <span
            className="h-1.5 w-1.5 rounded-full animate-pulse-glow"
            style={{ background: "var(--gold)" }}
          />
          {label}
        </div>
      )}
      <h2
        className="font-display text-[clamp(2rem,4vw,3.25rem)] font-bold leading-tight"
        style={{ color: "var(--ink)" }}
      >
        {title}
      </h2>
      {description && (
        <p
          className="mt-4 text-base leading-relaxed sm:text-lg"
          style={{ color: "var(--ink-muted)" }}
        >
          {description}
        </p>
      )}
    </div>
  );
}
