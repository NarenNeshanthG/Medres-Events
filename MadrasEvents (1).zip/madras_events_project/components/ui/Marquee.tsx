"use client";

import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

/**
 * Infinitely scrolling marquee. Duplicates children to create a seamless loop.
 * Pauses on hover (via `.marquee-pause` parent). Set duration via `duration` (seconds).
 */
export function Marquee({
  children,
  duration = 40,
  reverse = false,
  className,
}: {
  children: ReactNode;
  duration?: number;
  reverse?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("marquee-pause mask-fade-x flex w-full overflow-hidden", className)}>
      <div
        className={cn("flex min-w-full shrink-0", reverse ? "animate-marquee-reverse" : "animate-marquee")}
        style={{ ["--marquee-duration" as string]: `${duration}s` }}
      >
        {children}
      </div>
      <div
        aria-hidden
        className={cn("flex min-w-full shrink-0", reverse ? "animate-marquee-reverse" : "animate-marquee")}
        style={{ ["--marquee-duration" as string]: `${duration}s` }}
      >
        {children}
      </div>
    </div>
  );
}
