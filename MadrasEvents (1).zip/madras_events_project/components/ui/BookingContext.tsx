"use client";

import { createContext, useContext, useState, type ReactNode } from "react";
import type { BookingContextValue } from "@/lib/types";

const BookingContext = createContext<BookingContextValue>({
  isOpen: false,
  initialService: "",
  initialPackage: "",
  openBooking: () => {},
  closeBooking: () => {},
});

export function BookingProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [initialService, setInitialService] = useState("");
  const [initialPackage, setInitialPackage] = useState<"standard" | "custom" | "service" | "">("");

  const openBooking = (
    service?: string,
    pkg?: "standard" | "custom" | "service"
  ) => {
    setInitialService(service ?? "");
    setInitialPackage(pkg ?? "service");
    setIsOpen(true);
    document.body.style.overflow = "hidden";
  };

  const closeBooking = () => {
    setIsOpen(false);
    document.body.style.overflow = "";
  };

  return (
    <BookingContext.Provider
      value={{ isOpen, initialService, initialPackage, openBooking, closeBooking }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking(): BookingContextValue {
  return useContext(BookingContext);
}
