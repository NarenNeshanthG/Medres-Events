import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

/** Frosted glass surface card with subtle hover lift. */
export function GlassCard({
  children,
  className,
  hover = true,
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}) {
  return (
    <div
      className={cn(
        "glass rounded-3xl p-6 transition-all duration-500 ease-out",
        hover && "hover:-translate-y-1 hover:border-white/20 hover:bg-white/[0.05]",
        className,
      )}
    >
      {children}
    </div>
  );
}
