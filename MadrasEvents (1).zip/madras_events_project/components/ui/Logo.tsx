import type { ReactNode } from "react";

/** Madras Events brand logo — elegant text mark with gold accent */
export function Logo({ size = "default" }: { size?: "default" | "lg" }) {
  const isLg = size === "lg";

  return (
    <div className={`flex items-center gap-2 select-none ${isLg ? "gap-3" : "gap-2"}`}>
      {/* Emblem */}
      <div
        className={`relative grid place-items-center rounded-full shrink-0 ${isLg ? "h-12 w-12" : "h-9 w-9"}`}
        style={{
          background: "linear-gradient(135deg, var(--gold), var(--gold-bright))",
          boxShadow: "0 4px 16px var(--gold-glow)",
        }}
      >
        <span
          className={`font-display font-bold text-white ${isLg ? "text-xl" : "text-base"}`}
          style={{ lineHeight: 1, letterSpacing: "-0.01em" }}
        >
          M
        </span>
      </div>

      {/* Wordmark */}
      <div>
        <p
          className={`font-display font-bold leading-none tracking-tight ${isLg ? "text-2xl" : "text-lg"}`}
          style={{ color: "var(--ink)" }}
        >
          Madras{" "}
          <span style={{ color: "var(--gold)" }}>Events</span>
        </p>
        <p
          className={`font-sans tracking-widest uppercase ${isLg ? "text-xs" : "text-[10px]"}`}
          style={{ color: "var(--ink-faint)", letterSpacing: "0.15em" }}
        >
          Event Management
        </p>
      </div>
    </div>
  );
}
