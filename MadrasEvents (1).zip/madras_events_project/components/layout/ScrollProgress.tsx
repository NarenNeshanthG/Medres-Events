"use client";

import { motion, useScroll, useSpring } from "motion/react";

/** Thin gradient progress bar fixed to the top of the viewport. */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.3 });

  return (
    <motion.div
      style={{ scaleX }}
      className="fixed left-0 top-0 z-[9000] h-0.5 w-full origin-left bg-gradient-to-r from-[#4f7cff] via-[#8a5cff] to-[#4fe8ff]"
    />
  );
}
