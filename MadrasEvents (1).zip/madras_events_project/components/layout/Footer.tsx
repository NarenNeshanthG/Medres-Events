"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { Icon } from "@/components/ui/Icon";
import { Reveal } from "@/components/ui/Reveal";
import { FOOTER_NAV, FOOTER_SERVICES, SOCIALS, CONTACT_INFO } from "@/lib/data";
import { useBooking } from "@/components/ui/BookingContext";

export function Footer() {
  const { openBooking } = useBooking();
  const year = new Date().getFullYear();

  return (
    <footer
      className="relative overflow-hidden"
      style={{ borderTop: "1px solid var(--border)", background: "var(--bg-3)" }}
    >
      {/* Gold blob */}
      <div
        className="blob -bottom-40 left-1/4 h-80 w-80 opacity-20"
        style={{ background: "var(--gold)" }}
      />

      <div className="relative section-pad mx-auto max-w-7xl py-20">
        {/* CTA Strip */}
        <Reveal>
          <div
            className="glass-strong mb-20 flex flex-col items-center gap-6 rounded-3xl px-8 py-12 text-center md:flex-row md:justify-between md:text-left"
          >
            <div>
              <h3
                className="font-display text-3xl font-bold sm:text-4xl"
                style={{ color: "var(--ink)" }}
              >
                Ready to create an unforgettable event?
              </h3>
              <p className="mt-2 text-base" style={{ color: "var(--ink-muted)" }}>
                Let's bring your vision to life. Get in touch today.
              </p>
            </div>
            <button
              onClick={() => openBooking()}
              className="btn-gold inline-flex shrink-0 items-center gap-2 rounded-full px-8 py-4 text-sm font-semibold text-white"
            >
              Book an Event <ArrowRight size={16} />
            </button>
          </div>
        </Reveal>

        {/* Main grid */}
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand column */}
          <div className="lg:col-span-1">
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed" style={{ color: "var(--ink-muted)" }}>
              Creating extraordinary events across India. Your celebration deserves nothing less than perfection.
            </p>
            <div className="mt-6 flex gap-3">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-full transition-all"
                  style={{
                    border: "1px solid var(--border)",
                    color: "var(--ink-muted)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = "var(--gold)";
                    (e.currentTarget as HTMLAnchorElement).style.color = "var(--gold)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = "var(--border)";
                    (e.currentTarget as HTMLAnchorElement).style.color = "var(--ink-muted)";
                  }}
                >
                  <Icon name={s.icon} size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4
              className="mb-4 text-sm font-semibold uppercase tracking-wider"
              style={{ color: "var(--ink-faint)" }}
            >
              Navigation
            </h4>
            <ul className="space-y-3">
              {FOOTER_NAV.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-sm transition-colors"
                    style={{ color: "var(--ink-muted)" }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = "var(--gold)")}
                    onMouseLeave={(e) => (e.currentTarget.style.color = "var(--ink-muted)")}
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4
              className="mb-4 text-sm font-semibold uppercase tracking-wider"
              style={{ color: "var(--ink-faint)" }}
            >
              Services
            </h4>
            <ul className="space-y-3">
              {FOOTER_SERVICES.map((s) => (
                <li key={s}>
                  <Link
                    href="/services"
                    className="text-sm transition-colors"
                    style={{ color: "var(--ink-muted)" }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = "var(--gold)")}
                    onMouseLeave={(e) => (e.currentTarget.style.color = "var(--ink-muted)")}
                  >
                    {s}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="mb-4 text-sm font-semibold uppercase tracking-wider"
              style={{ color: "var(--ink-faint)" }}
            >
              Contact Us
            </h4>
            <div className="space-y-2.5 text-sm" style={{ color: "var(--ink-muted)" }}>
              <p>{CONTACT_INFO.email}</p>
              <p>{CONTACT_INFO.phone}</p>
              <p>{CONTACT_INFO.phone2}</p>
              <p className="mt-3 text-xs leading-relaxed">{CONTACT_INFO.address}</p>
              <p className="text-xs">{CONTACT_INFO.hours}</p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="mt-16 flex flex-col items-center justify-between gap-4 pt-8 text-sm sm:flex-row"
          style={{ borderTop: "1px solid var(--border)", color: "var(--ink-faint)" }}
        >
          <p>© {year} Madras Events. All rights reserved.</p>
          <p>Crafted with passion for perfect events.</p>
        </div>
      </div>
    </footer>
  );
}
