"use client";

import { AnimatePresence, motion } from "motion/react";
import { X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV_LINKS } from "@/lib/data";
import { Logo } from "@/components/ui/Logo";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { useBooking } from "@/components/ui/BookingContext";

interface Props {
  open: boolean;
  onClose: () => void;
}

export function MobileMenu({ open, onClose }: Props) {
  const pathname = usePathname();
  const { openBooking } = useBooking();

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[9500]"
            style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="fixed right-0 top-0 z-[9600] flex h-full w-80 max-w-full flex-col"
            style={{ background: "var(--bg)", borderLeft: "1px solid var(--border)" }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5" style={{ borderBottom: "1px solid var(--border)" }}>
              <Logo />
              <div className="flex items-center gap-2">
                <ThemeToggle />
                <button
                  onClick={onClose}
                  aria-label="Close menu"
                  className="grid h-9 w-9 place-items-center rounded-full"
                  style={{ border: "1px solid var(--border)", color: "var(--ink)" }}
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Links */}
            <nav className="flex-1 overflow-y-auto px-6 py-6">
              <ul className="space-y-1">
                {NAV_LINKS.map((link, i) => {
                  const isActive = pathname === link.href;
                  return (
                    <motion.li
                      key={link.href}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * i, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                    >
                      <Link
                        href={link.href}
                        onClick={onClose}
                        className="flex items-center gap-3 rounded-xl px-4 py-3 text-base font-medium transition-colors"
                        style={{
                          color: isActive ? "var(--gold)" : "var(--ink)",
                          background: isActive ? "var(--gold-glow)" : "transparent",
                        }}
                      >
                        {isActive && (
                          <span
                            className="h-1.5 w-1.5 rounded-full shrink-0"
                            style={{ background: "var(--gold)" }}
                          />
                        )}
                        {link.label}
                      </Link>
                    </motion.li>
                  );
                })}
              </ul>
            </nav>

            {/* CTA */}
            <div className="px-6 pb-8" style={{ borderTop: "1px solid var(--border)", paddingTop: "1.5rem" }}>
              <button
                onClick={() => { onClose(); openBooking(); }}
                className="btn-gold w-full rounded-full py-3.5 text-sm font-semibold text-white"
              >
                Book an Event
              </button>
              <p className="mt-4 text-center text-xs" style={{ color: "var(--ink-faint)" }}>
                hello@madrasevents.com · +91 98765 43210
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
