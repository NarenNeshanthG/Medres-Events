"use client";

import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { Menu } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV_LINKS } from "@/lib/data";
import { Logo } from "@/components/ui/Logo";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { MobileMenu } from "./MobileMenu";
import { useBooking } from "@/components/ui/BookingContext";

/** Sticky navbar with gold frost glass effect after scroll, active route highlighting. */
export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();
  const { openBooking } = useBooking();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-x-0 top-0 z-[9000] flex justify-center px-4 pt-3"
      >
        <nav
          className="flex w-full max-w-7xl items-center justify-between rounded-full px-5 py-3 transition-all duration-500"
          style={
            scrolled
              ? { background: "var(--glass-bg)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)", boxShadow: "0 8px 40px -12px rgba(0,0,0,0.3)" }
              : { background: "transparent", border: "1px solid transparent" }
          }
        >
          {/* Logo */}
          <Link href="/" aria-label="Madras Events home" className="shrink-0">
            <Logo />
          </Link>

          {/* Desktop nav links */}
          <ul className="hidden items-center gap-1 lg:flex">
            {NAV_LINKS.map((link) => {
              const isActive = pathname === link.href;
              return (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="group relative rounded-full px-4 py-2 text-sm font-medium transition-colors"
                    style={{
                      color: isActive ? "var(--gold)" : "var(--ink-muted)",
                    }}
                  >
                    {link.label}
                    <span
                      className="absolute inset-x-4 -bottom-0.5 h-px origin-left transition-transform duration-300"
                      style={{
                        background: "var(--gold)",
                        transform: isActive ? "scaleX(1)" : "scaleX(0)",
                      }}
                    />
                    {/* Hover underline for non-active */}
                    {!isActive && (
                      <span
                        className="absolute inset-x-4 -bottom-0.5 h-px origin-left scale-x-0 transition-transform duration-300 group-hover:scale-x-100"
                        style={{ background: "var(--gold)" }}
                      />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* Right side: theme toggle + CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <ThemeToggle />
            <button
              onClick={() => openBooking()}
              className="btn-gold rounded-full px-5 py-2.5 text-sm font-semibold text-white inline-flex items-center gap-2"
            >
              Book an Event
            </button>
          </div>

          {/* Mobile: theme toggle + hamburger */}
          <div className="flex items-center gap-2 lg:hidden">
            <ThemeToggle />
            <button
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu"
              className="grid h-10 w-10 place-items-center rounded-full transition-colors"
              style={{ border: "1px solid var(--border)", color: "var(--ink)" }}
            >
              <Menu size={18} />
            </button>
          </div>
        </nav>
      </motion.header>

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
    </>
  );
}
