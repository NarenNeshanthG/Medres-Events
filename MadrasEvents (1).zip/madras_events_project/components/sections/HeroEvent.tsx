"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowRight, CalendarDays, Sparkles } from "lucide-react";
import { useBooking } from "@/components/ui/BookingContext";

const HEADLINE = ["We Create", "Unforgettable", "Moments."];

const PARTICLES = [
  { x: "15%", y: "20%", size: 4, dur: 5, delay: 0 },
  { x: "80%", y: "15%", size: 3, dur: 6, delay: 1 },
  { x: "10%", y: "70%", size: 5, dur: 7, delay: 0.5 },
  { x: "70%", y: "75%", size: 3, dur: 5, delay: 2 },
  { x: "45%", y: "10%", size: 4, dur: 8, delay: 1.5 },
  { x: "90%", y: "50%", size: 3, dur: 6, delay: 0.3 },
  { x: "25%", y: "85%", size: 4, dur: 7, delay: 2.5 },
  { x: "60%", y: "30%", size: 2, dur: 5, delay: 1 },
];

export function HeroEvent() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yContent = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  const { openBooking } = useBooking();

  return (
    <section
      id="home"
      ref={ref}
      className="relative flex min-h-screen items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0" style={{ background: "var(--bg)" }} />
        {/* Radial gold glow */}
        <div
          className="absolute left-1/2 top-1/2 h-[70vmin] w-[70vmin] -translate-x-1/2 -translate-y-1/2 rounded-full animate-spin-slow opacity-30"
          style={{
            background: "conic-gradient(from 0deg, var(--gold-glow), transparent, var(--gold-glow), transparent)",
            filter: "blur(80px)",
          }}
        />
        <div
          className="absolute left-1/2 top-1/2 h-[40vmin] w-[40vmin] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-20"
          style={{ background: "var(--gold)", filter: "blur(120px)" }}
        />
        <div className="bg-grid absolute inset-0 opacity-30 [mask-image:radial-gradient(ellipse_at_center,#000_30%,transparent_75%)]" />
      </div>

      {/* Floating blobs */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div
          className="blob left-[8%] top-[20%] h-72 w-72 animate-float opacity-20"
          style={{ background: "var(--gold)" }}
        />
        <div
          className="blob right-[10%] top-[28%] h-80 w-80 animate-float-slow opacity-15"
          style={{ background: "var(--gold-soft)" }}
        />
      </div>

      {/* Gold particles */}
      {PARTICLES.map((p, i) => (
        <div
          key={i}
          className="pointer-events-none absolute -z-10 rounded-full animate-particle"
          style={{
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            background: "var(--gold)",
            "--dur": `${p.dur}s`,
            "--delay": `${p.delay}s`,
          } as React.CSSProperties}
        />
      ))}

      {/* Content */}
      <motion.div
        style={{ y: yContent, opacity }}
        className="relative mx-auto max-w-5xl px-6 text-center"
      >
        {/* Label badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="mx-auto mb-8 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium backdrop-blur-sm"
          style={{
            border: "1px solid var(--border-strong)",
            color: "var(--gold)",
            background: "var(--gold-glow)",
          }}
        >
          <Sparkles size={12} style={{ color: "var(--gold)" }} />
          Premium Event Management · Est. 2016
        </motion.div>

        {/* Headline */}
        <h1
          className="font-display text-[clamp(3rem,9vw,6.5rem)] font-bold leading-[0.95] tracking-tight"
        >
          {HEADLINE.map((line, li) => (
            <span key={li} className="block overflow-hidden">
              <motion.span
                className="inline-block"
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ delay: 0.5 + li * 0.15, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              >
                {li === 2 ? (
                  <span className="text-gradient-gold">{line}</span>
                ) : (
                  <span style={{ color: "var(--ink)" }}>{line}</span>
                )}
              </motion.span>
            </span>
          ))}
        </h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className="mx-auto mt-7 max-w-2xl text-lg leading-relaxed sm:text-xl"
          style={{ color: "var(--ink-muted)" }}
        >
          From intimate weddings to grand corporate galas — we craft every detail with precision,
          passion, and a dedication to creating memories that last a lifetime.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.8 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <button
            onClick={() => openBooking()}
            className="btn-gold inline-flex items-center gap-2 rounded-full px-8 py-4 text-base font-semibold text-white"
          >
            Book Your Event <CalendarDays size={18} />
          </button>
          <a
            href="/services"
            className="btn-ghost-gold inline-flex items-center gap-2 rounded-full px-8 py-4 text-base font-semibold"
          >
            Explore Services <ArrowRight size={18} />
          </a>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6, duration: 0.8 }}
          className="mt-12 flex flex-wrap items-center justify-center gap-6"
        >
          {["500+ Events", "350+ Happy Clients", "12+ Cities", "8+ Years"].map((badge) => (
            <div
              key={badge}
              className="flex items-center gap-2 text-sm font-medium"
              style={{ color: "var(--ink-muted)" }}
            >
              <span className="h-1 w-1 rounded-full" style={{ background: "var(--gold)" }} />
              {badge}
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.a
        href="#stats"
        aria-label="Scroll down"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div
          className="flex h-10 w-6 justify-center rounded-full pt-2"
          style={{ border: "1px solid var(--border-strong)" }}
        >
          <span
            className="h-2 w-1 rounded-full animate-scroll-dot"
            style={{ background: "var(--gold)" }}
          />
        </div>
      </motion.a>
    </section>
  );
}
