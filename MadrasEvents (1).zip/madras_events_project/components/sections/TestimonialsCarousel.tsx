"use client";

import { useRef, useState } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { TESTIMONIALS } from "@/lib/data";

export function TestimonialsCarousel() {
  const [active, setActive] = useState(0);
  const total = TESTIMONIALS.length;

  const prev = () => setActive((a) => (a - 1 + total) % total);
  const next = () => setActive((a) => (a + 1) % total);

  const t = TESTIMONIALS[active];

  return (
    <section className="py-28 section-pad overflow-hidden" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          label="Testimonials"
          title={
            <>
              Moments They{" "}
              <span className="text-gradient-gold">Cherish Forever</span>
            </>
          }
          description="Don't take our word for it. Hear from the couples, families, and companies whose events we've had the privilege of creating."
        />

        <div className="relative mx-auto max-w-3xl">
          {/* Quote icon */}
          <div
            className="mx-auto mb-8 grid h-14 w-14 place-items-center rounded-full"
            style={{ background: "var(--gold-glow)", border: "1px solid var(--border-strong)" }}
          >
            <Quote size={24} style={{ color: "var(--gold)" }} />
          </div>

          {/* Testimonial card */}
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-3xl p-8 text-center md:p-12"
            style={{
              background: "var(--bg-card)",
              border: "1px solid var(--border)",
            }}
          >
            {/* Stars */}
            <div className="flex justify-center gap-1 mb-6">
              {Array.from({ length: t.rating }).map((_, i) => (
                <Star key={i} size={18} fill="var(--gold)" style={{ color: "var(--gold)" }} />
              ))}
            </div>

            <blockquote
              className="font-display text-xl font-medium italic leading-relaxed md:text-2xl"
              style={{ color: "var(--ink)" }}
            >
              &ldquo;{t.text}&rdquo;
            </blockquote>

            <div className="mt-8">
              <p className="font-semibold text-sm" style={{ color: "var(--ink)" }}>{t.name}</p>
              <p className="text-sm mt-1" style={{ color: "var(--gold)" }}>{t.event}</p>
            </div>
          </motion.div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prev}
              aria-label="Previous testimonial"
              className="grid h-10 w-10 place-items-center rounded-full transition-colors"
              style={{ border: "1px solid var(--border)", color: "var(--ink-muted)" }}
            >
              <ChevronLeft size={18} />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  aria-label={`Go to testimonial ${i + 1}`}
                  className="h-2 rounded-full transition-all duration-300"
                  style={{
                    width: i === active ? 24 : 8,
                    background: i === active ? "var(--gold)" : "var(--border)",
                  }}
                />
              ))}
            </div>

            <button
              onClick={next}
              aria-label="Next testimonial"
              className="grid h-10 w-10 place-items-center rounded-full transition-colors"
              style={{ border: "1px solid var(--border)", color: "var(--ink-muted)" }}
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
