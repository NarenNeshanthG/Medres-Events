"use client";

import { motion } from "motion/react";
import { CalendarDays, ArrowRight } from "lucide-react";
import Link from "next/link";
import { Reveal } from "@/components/ui/Reveal";
import { useBooking } from "@/components/ui/BookingContext";

export function HomeCTA() {
  const { openBooking } = useBooking();

  return (
    <section className="py-24 section-pad" style={{ background: "var(--bg-3)" }}>
      <div className="mx-auto max-w-4xl">
        <Reveal>
          <div
            className="relative overflow-hidden rounded-3xl p-12 text-center"
            style={{
              background: "var(--bg-2)",
              border: "1px solid var(--border-strong)",
            }}
          >
            {/* Gold glow */}
            <div
              className="pointer-events-none absolute inset-0 opacity-30"
              style={{
                background: "radial-gradient(ellipse at center, var(--gold-glow) 0%, transparent 70%)",
              }}
            />

            <div className="relative">
              <div
                className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold uppercase tracking-widest"
                style={{ border: "1px solid var(--border-strong)", color: "var(--gold)", background: "var(--gold-glow)" }}
              >
                <span className="h-1.5 w-1.5 rounded-full animate-pulse-glow" style={{ background: "var(--gold)" }} />
                Limited Dates Available
              </div>

              <h2
                className="font-display text-[clamp(2rem,5vw,3.5rem)] font-bold leading-tight"
                style={{ color: "var(--ink)" }}
              >
                Your Dream Event Awaits
              </h2>
              <p
                className="mt-4 text-lg leading-relaxed max-w-xl mx-auto"
                style={{ color: "var(--ink-muted)" }}
              >
                Don't wait until it's too late. Book a consultation today and let's start planning the event of a lifetime.
              </p>

              <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
                <button
                  onClick={() => openBooking()}
                  className="btn-gold inline-flex items-center gap-2 rounded-full px-8 py-4 text-base font-semibold text-white"
                >
                  Book Your Event <CalendarDays size={18} />
                </button>
                <Link
                  href="/contact"
                  className="btn-ghost-gold inline-flex items-center gap-2 rounded-full px-8 py-4 text-base font-semibold"
                >
                  Contact Us <ArrowRight size={18} />
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
