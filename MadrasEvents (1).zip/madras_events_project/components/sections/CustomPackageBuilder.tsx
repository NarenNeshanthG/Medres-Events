"use client";

import { useState } from "react";
import { Plus, Minus, ArrowRight, Settings } from "lucide-react";
import { Reveal } from "@/components/ui/Reveal";
import { CUSTOM_ADDONS } from "@/lib/data";
import { calculateAddonTotal, formatINR } from "@/lib/booking";
import { useBooking } from "@/components/ui/BookingContext";

export function CustomPackageBuilder() {
  const { openBooking } = useBooking();
  const [quantities, setQuantities] = useState<Record<string, number>>({});

  const updateQty = (id: string, qty: number, minQty: number) => {
    // If dropping below minimum, remove it (set to 0). Otherwise, ensure it meets minQty.
    const finalQty = qty > 0 && qty < minQty ? minQty : Math.max(0, qty);
    setQuantities((prev) => ({ ...prev, [id]: finalQty }));
  };

  const { total, hasVariablePrice } = calculateAddonTotal(quantities);

  return (
    <section className="py-20 section-pad" style={{ background: "var(--bg-2)" }}>
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4" style={{ color: "var(--ink)" }}>
              Build Your <span className="text-gradient-gold">Custom Package</span>
            </h2>
            <p className="max-w-2xl mx-auto text-lg" style={{ color: "var(--ink-muted)" }}>
              Tailor your event exactly how you envision it. Select the add-ons you need and get an instant estimate.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Add-ons List */}
            <div className="lg:col-span-2 space-y-4">
              {CUSTOM_ADDONS.map((addon) => {
                const qty = quantities[addon.id] || 0;
                const isSelected = qty > 0;

                return (
                  <div
                    key={addon.id}
                    className="flex flex-col sm:flex-row gap-6 items-start sm:items-center p-6 rounded-2xl transition-all"
                    style={{
                      background: isSelected ? "var(--gold-glow)" : "var(--bg-card)",
                      border: `1px solid ${isSelected ? "var(--gold)" : "var(--border)"}`,
                    }}
                  >
                    <div className="flex-1">
                      <h4 className="font-display text-xl font-bold mb-1" style={{ color: "var(--ink)" }}>
                        {addon.name}
                      </h4>
                      <p className="text-sm mb-2" style={{ color: "var(--ink-muted)" }}>{addon.description}</p>
                      
                      {addon.pricePerUnit !== null ? (
                        <p className="text-sm font-semibold" style={{ color: "var(--gold)" }}>
                          {formatINR(addon.pricePerUnit)} / {addon.unit}
                          <span className="text-xs font-normal ml-2" style={{ color: "var(--ink-faint)" }}>
                            (Min: {addon.minQty})
                          </span>
                        </p>
                      ) : (
                        <p className="text-sm font-semibold italic" style={{ color: "var(--gold)" }}>
                          Price on inquiry
                        </p>
                      )}
                      {addon.variableNote && (
                        <p className="text-xs mt-1" style={{ color: "var(--ink-faint)" }}>{addon.variableNote}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-4 bg-black/10 rounded-full p-1.5" style={{ background: "var(--bg-3)" }}>
                      <button
                        onClick={() => updateQty(addon.id, qty - 1, addon.minQty)}
                        className="grid h-10 w-10 place-items-center rounded-full transition-colors disabled:opacity-30"
                        style={{ border: "1px solid var(--border)", color: "var(--ink)" }}
                        disabled={qty === 0}
                      >
                        <Minus size={16} />
                      </button>
                      <span className="w-8 text-center text-lg font-bold" style={{ color: "var(--ink)" }}>{qty}</span>
                      <button
                        onClick={() => updateQty(addon.id, qty + 1, addon.minQty)}
                        className="grid h-10 w-10 place-items-center rounded-full transition-colors"
                        style={{ border: "1px solid var(--gold)", color: "var(--gold)", background: "var(--gold-glow)" }}
                        disabled={qty >= addon.maxQty}
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Sticky Summary Panel */}
            <div className="lg:col-span-1">
              <div className="sticky top-28 rounded-3xl p-6 md:p-8" style={{ background: "var(--bg-card)", border: "1px solid var(--border)" }}>
                <div className="flex items-center gap-3 mb-6">
                  <Settings size={24} style={{ color: "var(--gold)" }} />
                  <h3 className="font-display text-2xl font-bold" style={{ color: "var(--ink)" }}>Estimate</h3>
                </div>

                <div className="space-y-4 mb-8 min-h-[100px]">
                  {Object.entries(quantities).filter(([_, q]) => q > 0).length === 0 ? (
                    <p className="text-sm text-center italic py-8" style={{ color: "var(--ink-faint)" }}>
                      Select add-ons to build your package
                    </p>
                  ) : (
                    <>
                      {Object.entries(quantities).map(([id, qty]) => {
                        if (qty === 0) return null;
                        const addon = CUSTOM_ADDONS.find(a => a.id === id)!;
                        return (
                          <div key={id} className="flex justify-between text-sm">
                            <span style={{ color: "var(--ink)" }}>{addon.name} <span style={{ color: "var(--ink-faint)" }}>× {qty}</span></span>
                            <span className="font-semibold" style={{ color: "var(--ink)" }}>
                              {addon.pricePerUnit ? formatINR(addon.pricePerUnit * qty) : "Inquiry"}
                            </span>
                          </div>
                        );
                      })}
                    </>
                  )}
                </div>

                <div className="pt-6" style={{ borderTop: "1px solid var(--border)" }}>
                  <div className="flex justify-between items-end mb-6">
                    <span className="text-base font-semibold" style={{ color: "var(--ink-muted)" }}>Total Estimate</span>
                    <div className="text-right">
                      <span className="font-display text-3xl font-bold" style={{ color: "var(--gold)" }}>
                        {formatINR(total)}
                      </span>
                      {hasVariablePrice && (
                        <p className="text-xs mt-1 italic" style={{ color: "var(--ink-muted)" }}>
                          + Flower Decor Inquiry
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      // Note: We don't directly pass 'quantities' to openBooking since it manages its own state,
                      // but the user will select custom package and re-enter quantities in the modal.
                      // A more advanced implementation would pass initial custom addons to the context.
                      openBooking("", "custom");
                    }}
                    className="w-full btn-gold px-6 py-4 rounded-full text-base font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    Proceed with Custom <ArrowRight size={18} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
