"use client";

import { Check, ArrowRight, Package } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { STANDARD_PACKAGE } from "@/lib/data";
import { formatINR } from "@/lib/booking";
import { useBooking } from "@/components/ui/BookingContext";

export function StandardPackage() {
  const { openBooking } = useBooking();

  return (
    <section className="pt-32 pb-20 section-pad" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <SectionHeading
            label="Pricing Options"
            title={<>Transparent <span className="text-gradient-gold">Pricing</span></>}
            description="Choose our comprehensive standard package or build a custom experience tailored to your exact needs."
          />
        </div>

        <Reveal>
          <div className="mx-auto max-w-3xl">
            <div
              className="relative overflow-hidden rounded-3xl p-8 md:p-12"
              style={{
                background: "var(--bg-2)",
                border: "2px solid var(--gold)",
                boxShadow: "0 20px 40px -15px var(--gold-glow)",
              }}
            >
              {/* Popular badge */}
              <div
                className="absolute right-0 top-0 rounded-bl-2xl px-6 py-2 text-xs font-bold uppercase tracking-widest text-white"
                style={{ background: "var(--btn-primary-bg)" }}
              >
                Most Popular
              </div>

              <div className="flex flex-col md:flex-row gap-12 items-center">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="grid h-12 w-12 place-items-center rounded-full" style={{ background: "var(--gold-glow)" }}>
                      <Package size={24} style={{ color: "var(--gold)" }} />
                    </div>
                    <h3 className="font-display text-3xl font-bold" style={{ color: "var(--ink)" }}>
                      {STANDARD_PACKAGE.name}
                    </h3>
                  </div>
                  <p className="text-base mb-8" style={{ color: "var(--ink-muted)" }}>
                    {STANDARD_PACKAGE.tagline}
                  </p>

                  <ul className="space-y-4 mb-8">
                    {STANDARD_PACKAGE.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Check size={20} style={{ color: "var(--gold)", flexShrink: 0, marginTop: 2 }} />
                        <span style={{ color: "var(--ink)" }}>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="w-full md:w-auto flex flex-col items-center md:items-end">
                  <div className="text-center md:text-right mb-6">
                    <p className="text-sm font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--ink-faint)" }}>
                      Fixed Price
                    </p>
                    <p className="font-display text-5xl font-bold" style={{ color: "var(--ink)" }}>
                      {formatINR(STANDARD_PACKAGE.price)}
                    </p>
                  </div>
                  <button
                    onClick={() => openBooking("", "standard")}
                    className="w-full md:w-auto btn-gold px-8 py-4 rounded-full text-base font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    Book Standard Package <ArrowRight size={18} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
