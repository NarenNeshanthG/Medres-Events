"use client";

import { ArrowRight, PartyPopper } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { ENTERTAINMENT_STALLS } from "@/lib/data";
import { useBooking } from "@/components/ui/BookingContext";

export function EntertainmentSection() {
  const { openBooking } = useBooking();

  return (
    <section className="py-24 section-pad" style={{ background: "var(--bg-2)" }}>
      <div className="mx-auto max-w-7xl">
        <div className="mb-16">
          <SectionHeading
            label="Entertainment Stalls"
            title={<>Elevate Your <span className="text-gradient-gold">Event Experience</span></>}
            description="Add that extra spark to your celebration with our premium entertainment stalls. Perfect for engaging guests and creating shareable moments."
          />
        </div>

        <StaggerGroup className="grid gap-8 md:grid-cols-3">
          {ENTERTAINMENT_STALLS.map((stall) => (
            <StaggerItem key={stall.id}>
              <div
                className="group relative flex flex-col overflow-hidden rounded-3xl"
                style={{ background: "var(--bg)", border: "1px solid var(--border)" }}
              >
                <div
                  className="absolute inset-x-0 top-0 h-1 transition-all duration-300 group-hover:h-2"
                  style={{ background: "var(--btn-primary-bg)" }}
                />
                <div className="p-8 flex flex-col h-full">
                  <div
                    className="mb-6 grid h-16 w-16 place-items-center rounded-2xl"
                    style={{ background: "var(--gold-glow)", border: "1px solid var(--border-strong)" }}
                  >
                    <Icon name={stall.icon} size={32} style={{ color: "var(--gold)" }} />
                  </div>
                  
                  <h3 className="font-display text-2xl font-bold mb-2" style={{ color: "var(--ink)" }}>
                    {stall.title}
                  </h3>
                  
                  <p className="text-base font-semibold mb-4" style={{ color: "var(--gold)" }}>
                    {stall.price}
                  </p>
                  
                  <p className="text-base leading-relaxed flex-1 mb-8" style={{ color: "var(--ink-muted)" }}>
                    {stall.description}
                  </p>
                  
                  <button
                    onClick={() => openBooking(stall.title, "service")}
                    className="w-full btn-gold px-6 py-3.5 rounded-full text-sm font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    Book Now <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
