"use client";

import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { TEAM } from "@/lib/data";
import { User } from "lucide-react";

export function TeamGrid() {
  return (
    <section className="py-24 section-pad" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          label="The Team"
          title={<>Meet the <span className="text-gradient-gold">Creators</span></>}
          description="The passionate individuals who work tirelessly behind the scenes to make your events extraordinary."
        />

        <StaggerGroup className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {TEAM.map((member) => (
            <StaggerItem key={member.name}>
              <div className="card-surface p-6 h-full flex flex-col text-center items-center">
                <div
                  className="mb-6 grid h-24 w-24 place-items-center rounded-full overflow-hidden"
                  style={{ background: "var(--bg-3)", border: "2px solid var(--border-strong)" }}
                >
                  <User size={40} style={{ color: "var(--ink-faint)" }} />
                </div>
                <h3 className="font-display text-xl font-bold mb-1" style={{ color: "var(--ink)" }}>
                  {member.name}
                </h3>
                <p className="text-sm font-medium mb-4 uppercase tracking-wider" style={{ color: "var(--gold)" }}>
                  {member.role}
                </p>
                <p className="text-sm leading-relaxed" style={{ color: "var(--ink-muted)" }}>
                  {member.bio}
                </p>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
