"use client";

import { motion } from "motion/react";
import { Sparkles } from "lucide-react";

export function AboutHero() {
  return (
    <section className="relative flex min-h-[60vh] items-center justify-center overflow-hidden pt-32 pb-20">
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0" style={{ background: "var(--bg)" }} />
        <div
          className="absolute left-1/2 top-1/2 h-[50vmin] w-[50vmin] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-20"
          style={{ background: "var(--gold)", filter: "blur(120px)" }}
        />
        <div className="bg-grid absolute inset-0 opacity-20 [mask-image:radial-gradient(ellipse_at_center,#000_20%,transparent_70%)]" />
      </div>

      <div className="relative mx-auto max-w-4xl px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium backdrop-blur-sm"
          style={{
            border: "1px solid var(--border-strong)",
            color: "var(--gold)",
            background: "var(--gold-glow)",
          }}
        >
          <Sparkles size={12} style={{ color: "var(--gold)" }} />
          Our Story
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-display text-[clamp(2.5rem,6vw,4.5rem)] font-bold leading-tight"
          style={{ color: "var(--ink)" }}
        >
          Crafting Moments That <span className="text-gradient-gold">Last a Lifetime</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed"
          style={{ color: "var(--ink-muted)" }}
        >
          We are more than just event planners. We are storytellers, designers, and creators dedicated to turning your vision into a breathtaking reality.
        </motion.p>
      </div>
    </section>
  );
}
