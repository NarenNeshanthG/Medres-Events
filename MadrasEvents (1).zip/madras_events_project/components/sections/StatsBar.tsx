"use client";

import { Reveal, StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { Counter } from "@/components/ui/Counter";
import { STATS } from "@/lib/data";

export function StatsBar() {
  return (
    <section id="stats" className="py-20" style={{ background: "var(--bg-2)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
      <div className="section-pad mx-auto max-w-7xl">
        <StaggerGroup className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {STATS.map((stat, i) => (
            <StaggerItem key={stat.label}>
              <div className="text-center">
                <div
                  className="font-display text-5xl font-bold leading-none md:text-6xl"
                  style={{ color: "var(--gold)" }}
                >
                  <Counter value={stat.value} suffix={stat.suffix} duration={2.5} />
                </div>
                <p className="mt-3 text-sm font-medium" style={{ color: "var(--ink-muted)" }}>
                  {stat.label}
                </p>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
