"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Icon } from "@/components/ui/Icon";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { SERVICES } from "@/lib/data";
import { useBooking } from "@/components/ui/BookingContext";

/** Shows the first 6 services as a preview on the Home page */
export function ServicesPreview() {
  const { openBooking } = useBooking();
  const preview = SERVICES.slice(0, 6);

  return (
    <section className="py-28 section-pad" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          label="What We Do"
          title={
            <>
              Events Crafted for{" "}
              <span className="text-gradient-gold">Every Occasion</span>
            </>
          }
          description="From intimate gatherings to grand celebrations, we bring expertise and artistry to every event we touch."
        />

        <StaggerGroup className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {preview.map((svc) => (
            <StaggerItem key={svc.id}>
              <div
                className="card-surface group relative flex flex-col gap-4 overflow-hidden p-6"
              >
                {/* Icon */}
                <div
                  className="grid h-12 w-12 place-items-center rounded-xl transition-colors"
                  style={{ background: "var(--gold-glow)", border: "1px solid var(--border-strong)" }}
                >
                  <Icon name={svc.icon} size={22} style={{ color: "var(--gold)" }} />
                </div>

                <div className="flex-1">
                  <h3
                    className="font-display text-xl font-semibold mb-2"
                    style={{ color: "var(--ink)" }}
                  >
                    {svc.title}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--ink-muted)" }}>
                    {svc.description}
                  </p>
                </div>

                <button
                  onClick={() => openBooking(svc.title, "service")}
                  className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold transition-colors"
                  style={{ color: "var(--gold)" }}
                >
                  Book Now <ArrowRight size={14} />
                </button>

                {/* Hover shimmer */}
                <div
                  className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background: "linear-gradient(135deg, transparent 60%, var(--gold-glow))",
                  }}
                />
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>

        <div className="mt-12 text-center">
          <Link
            href="/services"
            className="btn-ghost-gold inline-flex items-center gap-2 rounded-full px-8 py-3.5 text-sm font-semibold"
          >
            View All Services <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
