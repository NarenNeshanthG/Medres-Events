"use client";

import { useState } from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Send, Check } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { CONTACT_INFO } from "@/lib/data";

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("submitting");
    // Simulate API call
    setTimeout(() => setStatus("success"), 1500);
  };

  return (
    <section className="pt-32 pb-24 section-pad" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-6xl">
        <div className="mb-16">
          <SectionHeading
            label="Contact Us"
            title={<>Let's Plan Something <span className="text-gradient-gold">Amazing</span></>}
            description="Whether you have a fully formed vision or just an idea, we'd love to hear from you. Reach out to discuss your upcoming event."
          />
        </div>

        <div className="grid lg:grid-cols-5 gap-12 lg:gap-8">
          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h3 className="font-display text-2xl font-bold mb-6" style={{ color: "var(--ink)" }}>Get in Touch</h3>
              <p className="text-base leading-relaxed mb-8" style={{ color: "var(--ink-muted)" }}>
                Our team is ready to answer your questions and start planning your perfect event. We typically respond within 24 hours.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full" style={{ background: "var(--gold-glow)", border: "1px solid var(--border)" }}>
                  <Mail size={20} style={{ color: "var(--gold)" }} />
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1 uppercase tracking-wider" style={{ color: "var(--ink-faint)" }}>Email Us</p>
                  <a href={`mailto:${CONTACT_INFO.email}`} className="text-base font-medium transition-colors hover:text-[var(--gold)]" style={{ color: "var(--ink)" }}>
                    {CONTACT_INFO.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full" style={{ background: "var(--gold-glow)", border: "1px solid var(--border)" }}>
                  <Phone size={20} style={{ color: "var(--gold)" }} />
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1 uppercase tracking-wider" style={{ color: "var(--ink-faint)" }}>Call Us</p>
                  <p className="text-base font-medium" style={{ color: "var(--ink)" }}>{CONTACT_INFO.phone}</p>
                  <p className="text-base font-medium" style={{ color: "var(--ink)" }}>{CONTACT_INFO.phone2}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full" style={{ background: "var(--gold-glow)", border: "1px solid var(--border)" }}>
                  <MapPin size={20} style={{ color: "var(--gold)" }} />
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1 uppercase tracking-wider" style={{ color: "var(--ink-faint)" }}>Visit Us</p>
                  <p className="text-base font-medium leading-relaxed" style={{ color: "var(--ink)" }}>
                    {CONTACT_INFO.address.split(',').map((line, i) => (
                      <span key={i}>{line}<br /></span>
                    ))}
                  </p>
                  <p className="text-sm mt-2" style={{ color: "var(--ink-muted)" }}>{CONTACT_INFO.hours}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="rounded-3xl p-8 sm:p-10" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
              {status === "success" ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center py-12 text-center"
                >
                  <div className="mb-6 grid h-20 w-20 place-items-center rounded-full" style={{ background: "var(--gold-glow)", border: "2px solid var(--gold)" }}>
                    <Check size={36} style={{ color: "var(--gold)" }} />
                  </div>
                  <h3 className="font-display text-2xl font-bold mb-2" style={{ color: "var(--ink)" }}>Message Sent!</h3>
                  <p className="text-base max-w-sm mx-auto" style={{ color: "var(--ink-muted)" }}>
                    Thank you for reaching out. A member of our team will get back to you shortly.
                  </p>
                  <button
                    onClick={() => { setForm({ name: "", email: "", phone: "", message: "" }); setStatus("idle"); }}
                    className="mt-8 text-sm font-semibold hover:underline"
                    style={{ color: "var(--gold)" }}
                  >
                    Send another message
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium" style={{ color: "var(--ink)" }}>Your Name *</label>
                      <input
                        required
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="w-full rounded-xl px-4 py-3 text-sm transition-colors focus:outline-none"
                        style={{ background: "var(--bg-3)", color: "var(--ink)", border: "1px solid var(--border)" }}
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium" style={{ color: "var(--ink)" }}>Phone Number</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className="w-full rounded-xl px-4 py-3 text-sm transition-colors focus:outline-none"
                        style={{ background: "var(--bg-3)", color: "var(--ink)", border: "1px solid var(--border)" }}
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{ color: "var(--ink)" }}>Email Address *</label>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors focus:outline-none"
                      style={{ background: "var(--bg-3)", color: "var(--ink)", border: "1px solid var(--border)" }}
                      placeholder="john@example.com"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium" style={{ color: "var(--ink)" }}>Your Message *</label>
                    <textarea
                      required
                      rows={5}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors focus:outline-none resize-none"
                      style={{ background: "var(--bg-3)", color: "var(--ink)", border: "1px solid var(--border)" }}
                      placeholder="Tell us about your event..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={status === "submitting"}
                    className="w-full btn-gold rounded-xl py-4 text-sm font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-70"
                  >
                    {status === "submitting" ? "Sending..." : "Send Message"}
                    {status !== "submitting" && <Send size={16} />}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
