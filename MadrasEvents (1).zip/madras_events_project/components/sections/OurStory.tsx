"use client";

import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { VALUES, PROCESS } from "@/lib/data";

export function OurStory() {
  return (
    <section className="py-20 section-pad" style={{ background: "var(--bg-2)" }}>
      <div className="mx-auto max-w-7xl">
        {/* Mission, Vision, Values */}
        <div className="mb-24">
          <SectionHeading
            label="Our Philosophy"
            title={<>Driven by <span className="text-gradient-gold">Passion</span></>}
            description="We believe every event has a unique soul. Our goal is to bring that soul to life through meticulous planning and stunning design."
          />
          <StaggerGroup className="grid gap-8 md:grid-cols-3">
            {VALUES.map((val) => (
              <StaggerItem key={val.title}>
                <div className="card-surface p-8 h-full">
                  <div
                    className="mb-6 grid h-14 w-14 place-items-center rounded-2xl"
                    style={{ background: "var(--gold-glow)", border: "1px solid var(--border-strong)" }}
                  >
                    <Icon name={val.icon} size={24} style={{ color: "var(--gold)" }} />
                  </div>
                  <h3 className="mb-3 font-display text-2xl font-semibold" style={{ color: "var(--ink)" }}>
                    {val.title}
                  </h3>
                  <p className="leading-relaxed" style={{ color: "var(--ink-muted)" }}>
                    {val.text}
                  </p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>

        {/* Process */}
        <div>
          <SectionHeading
            label="How We Work"
            title={<>The <span className="text-gradient-gold">Planning Process</span></>}
            description="A seamless journey from our first conversation to the final guest's departure."
          />
          <div className="relative mx-auto max-w-4xl">
            <div className="absolute left-6 top-10 bottom-10 w-px" style={{ background: "var(--border-strong)" }} />
            <StaggerGroup className="space-y-12">
              {PROCESS.map((step, i) => (
                <StaggerItem key={step.step} direction="left">
                  <div className="relative flex gap-8 pl-14">
                    <div
                      className="absolute left-0 top-0 grid h-12 w-12 place-items-center rounded-full font-display text-xl font-bold"
                      style={{ background: "var(--bg-card)", border: "2px solid var(--gold)", color: "var(--gold)" }}
                    >
                      {step.step}
                    </div>
                    <div>
                      <h4 className="mb-2 font-display text-2xl font-semibold" style={{ color: "var(--ink)" }}>
                        {step.title}
                      </h4>
                      <p className="leading-relaxed" style={{ color: "var(--ink-muted)" }}>
                        {step.text}
                      </p>
                    </div>
                  </div>
                </StaggerItem>
              ))}
            </StaggerGroup>
          </div>
        </div>
      </div>
    </section>
  );
}
