"use client";

import { ArrowRight, Sparkles } from "lucide-react";
import { motion } from "motion/react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { Icon } from "@/components/ui/Icon";
import { SERVICES } from "@/lib/data";
import { useBooking } from "@/components/ui/BookingContext";

export function ServicesGrid() {
  const { openBooking } = useBooking();
  // Filter out stalls, as they have their own section
  const mainServices = SERVICES.filter((s) => s.category !== "stalls");

  return (
    <section className="pt-32 pb-20 section-pad" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium backdrop-blur-sm"
            style={{
              border: "1px solid var(--border-strong)",
              color: "var(--gold)",
              background: "var(--gold-glow)",
            }}
          >
            <Sparkles size={12} style={{ color: "var(--gold)" }} />
            Our Services
          </motion.div>
          <SectionHeading
            title={<>Crafting Extraordinary <span className="text-gradient-gold">Experiences</span></>}
            description="From intimate weddings to grand corporate galas, we offer a comprehensive range of event management services tailored to your unique vision."
          />
        </div>

        <StaggerGroup className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {mainServices.map((svc) => (
            <StaggerItem key={svc.id}>
              <div className="card-surface group relative flex flex-col gap-4 overflow-hidden p-8 h-full">
                <div
                  className="grid h-14 w-14 place-items-center rounded-xl transition-colors mb-2"
                  style={{ background: "var(--gold-glow)", border: "1px solid var(--border-strong)" }}
                >
                  <Icon name={svc.icon} size={28} style={{ color: "var(--gold)" }} />
                </div>

                <div className="flex-1">
                  <h3 className="font-display text-2xl font-bold mb-3" style={{ color: "var(--ink)" }}>
                    {svc.title}
                  </h3>
                  <p className="text-base leading-relaxed" style={{ color: "var(--ink-muted)" }}>
                    {svc.description}
                  </p>
                </div>

                <div className="mt-4 pt-4 flex items-center justify-between" style={{ borderTop: "1px solid var(--border)" }}>
                  <button
                    onClick={() => openBooking(svc.title, "service")}
                    className="btn-gold px-6 py-2.5 rounded-full text-sm font-semibold transition-colors flex items-center gap-2"
                  >
                    Book Now <ArrowRight size={14} />
                  </button>
                </div>

                {/* Hover shimmer */}
                <div
                  className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background: "linear-gradient(135deg, transparent 60%, var(--gold-glow))",
                  }}
                />
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
