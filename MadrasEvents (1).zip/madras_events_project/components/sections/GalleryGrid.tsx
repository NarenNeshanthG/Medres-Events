"use client";

import { motion } from "motion/react";
import { Sparkles, Expand } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerGroup, StaggerItem } from "@/components/ui/Reveal";

// Placeholder data since we don't have real images yet.
const GALLERY_ITEMS = [
  { id: 1, title: "Grand Royal Wedding", category: "Wedding", aspect: "aspect-[4/3]" },
  { id: 2, title: "Tech Corp Annual Gala", category: "Corporate", aspect: "aspect-[3/4]" },
  { id: 3, title: "Sunset Engagement", category: "Wedding", aspect: "aspect-[4/5]" },
  { id: 4, title: "Neon Birthday Bash", category: "Birthday", aspect: "aspect-square" },
  { id: 5, title: "Elegant Reception", category: "Wedding", aspect: "aspect-[16/9]" },
  { id: 6, title: "Product Launch Event", category: "Corporate", aspect: "aspect-[3/4]" },
  { id: 7, title: "360 Booth Fun", category: "Entertainment", aspect: "aspect-square" },
  { id: 8, title: "Haldi Ceremony Decor", category: "Wedding", aspect: "aspect-[4/3]" },
  { id: 9, title: "Outdoor Concert", category: "Event", aspect: "aspect-[16/9]" },
];

export function GalleryGrid() {
  return (
    <section className="pt-32 pb-20 section-pad" style={{ background: "var(--bg)" }}>
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium backdrop-blur-sm"
            style={{
              border: "1px solid var(--border-strong)",
              color: "var(--gold)",
              background: "var(--gold-glow)",
            }}
          >
            <Sparkles size={12} style={{ color: "var(--gold)" }} />
            Our Portfolio
          </motion.div>
          <SectionHeading
            title={<>Moments <span className="text-gradient-gold">Captured</span></>}
            description="Explore our gallery of past events, showcasing our dedication to design, detail, and creating unforgettable atmospheres."
          />
        </div>

        <StaggerGroup className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          {GALLERY_ITEMS.map((item) => (
            <StaggerItem key={item.id} className="break-inside-avoid">
              <div
                className={`group relative overflow-hidden rounded-2xl ${item.aspect}`}
                style={{ background: "var(--bg-3)", border: "1px solid var(--border)" }}
              >
                {/* Simulated Image Placeholder */}
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-black/20" style={{ background: "var(--bg-card)" }}>
                  <p className="font-display text-xl font-bold mb-2 opacity-50" style={{ color: "var(--ink)" }}>{item.title}</p>
                  <p className="text-xs uppercase tracking-widest opacity-50" style={{ color: "var(--gold)" }}>{item.category}</p>
                </div>

                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 grid h-12 w-12 place-items-center rounded-full bg-white/10 backdrop-blur-md text-white border border-white/20">
                    <Expand size={20} />
                  </div>
                </div>

                {/* Bottom text reveal */}
                <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-black/80 to-transparent transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <p className="font-display text-lg font-bold text-white mb-1">{item.title}</p>
                  <p className="text-xs uppercase tracking-widest text-white/70">{item.category}</p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
