"use client";

import { Icon } from "@/components/ui/Icon";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StaggerGroup, StaggerItem } from "@/components/ui/Reveal";
import { WHY_VENDRA } from "@/lib/data";

export function WhyMadras() {
  return (
    <section className="py-28 section-pad" style={{ background: "var(--bg-2)" }}>
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          label="Why Choose Us"
          title={
            <>
              The Madras Events{" "}
              <span className="text-gradient-gold">Difference</span>
            </>
          }
          description="We don't just plan events. We craft experiences that reflect your vision, exceed your expectations, and leave your guests in awe."
        />

        <StaggerGroup className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_VENDRA.map((item) => (
            <StaggerItem key={item.title}>
              <div
                className="group flex gap-4 rounded-2xl p-5 transition-all duration-300"
                style={{ border: "1px solid var(--border)", background: "var(--bg-card)" }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.borderColor = "var(--border-strong)";
                  (e.currentTarget as HTMLDivElement).style.transform = "translateY(-4px)";
                  (e.currentTarget as HTMLDivElement).style.boxShadow = "0 8px 32px var(--gold-glow)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.borderColor = "var(--border)";
                  (e.currentTarget as HTMLDivElement).style.transform = "translateY(0)";
                  (e.currentTarget as HTMLDivElement).style.boxShadow = "none";
                }}
              >
                <div
                  className="shrink-0 grid h-11 w-11 place-items-center rounded-xl"
                  style={{ background: "var(--gold-glow)", border: "1px solid var(--border-strong)" }}
                >
                  <Icon name={item.icon} size={20} style={{ color: "var(--gold)" }} />
                </div>
                <div>
                  <h3 className="text-base font-semibold mb-1" style={{ color: "var(--ink)" }}>
                    {item.title}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--ink-muted)" }}>
                    {item.text}
                  </p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </section>
  );
}
