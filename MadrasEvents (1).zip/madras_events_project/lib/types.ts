/**
 * Madras Events — TypeScript Interfaces & Types
 */

export interface ServiceItem {
  id: string;
  icon: string;
  title: string;
  description: string;
  category: "events" | "entertainment" | "decor" | "stalls";
  image?: string;
  price?: string;
}

export interface CustomAddon {
  id: string;
  name: string;
  pricePerUnit: number | null; // null = variable/inquiry-based
  minQty: number;
  maxQty: number;
  unit: string;
  description: string;
  variableNote?: string;
}

export interface StandardPackage {
  name: string;
  price: number;
  currency: string;
  tagline: string;
  features: string[];
  popular: boolean;
}

export interface GalleryItem {
  id: string;
  src: string;
  alt: string;
  category: "wedding" | "corporate" | "birthday" | "entertainment" | "decor";
  title: string;
}

export interface TeamMember {
  name: string;
  role: string;
  bio: string;
  image?: string;
}

export interface Testimonial {
  name: string;
  event: string;
  rating: number;
  text: string;
  location: string;
}

export interface BookingFormData {
  // Step 1 - Service
  selectedService: string;
  selectedPackage: "standard" | "custom" | "service" | "";

  // Step 2 - Event Details
  eventDate: string;
  eventTime: string;
  eventLocation: string;
  eventType: string;

  // Step 3 - Customer Details
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  specialRequirements: string;

  // Custom package selections
  customAddons: Record<string, number>; // addonId -> quantity
}

export interface BookingContextValue {
  isOpen: boolean;
  initialService: string;
  initialPackage: "standard" | "custom" | "service" | "";
  openBooking: (service?: string, pkg?: "standard" | "custom" | "service") => void;
  closeBooking: () => void;
}
