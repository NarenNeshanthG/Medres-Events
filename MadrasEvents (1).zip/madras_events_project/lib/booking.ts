/**
 * Madras Events — Booking state helpers & price calculation.
 */

import type { BookingFormData, CustomAddon } from "./types";
import { CUSTOM_ADDONS, STANDARD_PACKAGE } from "./data";

export const INITIAL_BOOKING_FORM: BookingFormData = {
  selectedService: "",
  selectedPackage: "",
  eventDate: "",
  eventTime: "",
  eventLocation: "",
  eventType: "",
  customerName: "",
  customerPhone: "",
  customerEmail: "",
  specialRequirements: "",
  customAddons: {},
};

/** Calculate the total price of selected custom add-ons */
export function calculateAddonTotal(customAddons: Record<string, number>): {
  total: number;
  hasVariablePrice: boolean;
  lineItems: { name: string; qty: number; unitPrice: number; subtotal: number }[];
} {
  let total = 0;
  let hasVariablePrice = false;
  const lineItems: { name: string; qty: number; unitPrice: number; subtotal: number }[] = [];

  for (const [addonId, qty] of Object.entries(customAddons)) {
    if (qty <= 0) continue;
    const addon = CUSTOM_ADDONS.find((a) => a.id === addonId);
    if (!addon) continue;

    if (addon.pricePerUnit === null) {
      hasVariablePrice = true;
    } else {
      const subtotal = addon.pricePerUnit * qty;
      total += subtotal;
      lineItems.push({ name: addon.name, qty, unitPrice: addon.pricePerUnit, subtotal });
    }
  }

  return { total, hasVariablePrice, lineItems };
}

/** Calculate package total (standard + addons) */
export function calculatePackageTotal(
  pkg: "standard" | "custom" | "service" | "",
  customAddons: Record<string, number>
): { basePrice: number; addonsTotal: number; total: number; hasVariablePrice: boolean } {
  const basePrice = pkg === "standard" ? STANDARD_PACKAGE.price : 0;
  const { total: addonsTotal, hasVariablePrice } = calculateAddonTotal(customAddons);
  return {
    basePrice,
    addonsTotal,
    total: basePrice + addonsTotal,
    hasVariablePrice,
  };
}

/** Validate a booking step; returns array of error messages (empty = valid) */
export function validateBookingStep(step: number, form: BookingFormData): string[] {
  const errors: string[] = [];

  if (step === 1) {
    if (!form.selectedService && !form.selectedPackage) {
      errors.push("Please select a service or package to continue.");
    }
  }

  if (step === 2) {
    if (!form.eventDate) errors.push("Please select an event date.");
    if (!form.eventTime) errors.push("Please enter an event time.");
    if (!form.eventLocation) errors.push("Please enter the event location.");
    if (!form.eventType) errors.push("Please select an event type.");
  }

  if (step === 3) {
    if (!form.customerName.trim()) errors.push("Please enter your name.");
    if (!form.customerPhone.trim()) errors.push("Please enter your phone number.");
    if (!/^\+?[\d\s\-()]{8,}$/.test(form.customerPhone.trim())) {
      errors.push("Please enter a valid phone number.");
    }
    if (!form.customerEmail.trim()) errors.push("Please enter your email address.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.customerEmail.trim())) {
      errors.push("Please enter a valid email address.");
    }
  }

  return errors;
}

/** Format INR price */
export function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

/** Get addon by id */
export function getAddon(id: string): CustomAddon | undefined {
  return CUSTOM_ADDONS.find((a) => a.id === id);
}
