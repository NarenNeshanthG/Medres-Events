/**
 * Madras Events — Centralized site content.
 * All copy and structured data lives here so sections stay presentational.
 */

import type { ServiceItem, CustomAddon, GalleryItem, TeamMember, Testimonial } from "./types";

export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Pricing", href: "/pricing" },
  { label: "Gallery", href: "/gallery" },
  { label: "Contact", href: "/contact" },
];

export const STATS = [
  { value: 500, suffix: "+", label: "Events Managed" },
  { value: 350, suffix: "+", label: "Happy Clients" },
  { value: 12, suffix: "+", label: "Cities Served" },
  { value: 8, suffix: "+", label: "Years Experience" },
];

export const SERVICES: ServiceItem[] = [
  {
    id: "wedding",
    icon: "Heart",
    title: "Wedding Ceremonies",
    description: "From intimate gatherings to grand celebrations, we craft weddings that tell your unique love story with elegance and precision.",
    category: "events",
    price: "Custom Quote",
  },
  {
    id: "corporate",
    icon: "Building2",
    title: "Corporate Events",
    description: "Professional conferences, product launches, award nights, and team-building events that leave a lasting impression.",
    category: "events",
    price: "Custom Quote",
  },
  {
    id: "birthday",
    icon: "Cake",
    title: "Birthday Celebrations",
    description: "Make every birthday extraordinary — themed parties, milestone celebrations, and surprises that become lifelong memories.",
    category: "events",
    price: "Custom Quote",
  },
  {
    id: "reception",
    icon: "Star",
    title: "Reception & Engagement",
    description: "Stunning reception setups and engagement parties designed to reflect your personality and impress every guest.",
    category: "events",
    price: "Custom Quote",
  },
  {
    id: "decor",
    icon: "Sparkles",
    title: "Event Decoration",
    description: "Transforming spaces into breathtaking experiences with floral arrangements, lighting, draping, and themed installations.",
    category: "decor",
    price: "Custom Quote",
  },
  {
    id: "catering",
    icon: "Utensils",
    title: "Catering Coordination",
    description: "Curated culinary experiences with expert vendor coordination for menus that delight every palate.",
    category: "events",
    price: "Custom Quote",
  },
  {
    id: "photo-booth",
    icon: "Camera",
    title: "Instant Photo Booth",
    description: "Premium instant photo booths with custom frames, props, and instant prints — the highlight of every event.",
    category: "stalls",
    price: "₹8,000 onwards",
  },
  {
    id: "360-camera",
    icon: "Video",
    title: "360° Camera Booth",
    description: "Capture stunning slow-motion 360° videos that go viral. The ultimate entertainment experience for modern events.",
    category: "stalls",
    price: "₹12,000 onwards",
  },
  {
    id: "grand-entry",
    icon: "Wand2",
    title: "Grand Entry",
    description: "Make a spectacular entrance with smoke machines, cold pyrotechnics, petal showers, and LED effects.",
    category: "stalls",
    price: "₹15,000 onwards",
  },
];

export const ENTERTAINMENT_STALLS = SERVICES.filter((s) => s.category === "stalls");

export const CUSTOM_ADDONS: CustomAddon[] = [
  {
    id: "honeycomb-lights",
    name: "Honeycomb Lights",
    pricePerUnit: 3500,
    minQty: 2,
    maxQty: 20,
    unit: "unit",
    description: "Elegant hexagonal light panels that create a stunning ambient effect",
  },
  {
    id: "stage-lights",
    name: "Stage Lights",
    pricePerUnit: 5000,
    minQty: 2,
    maxQty: 10,
    unit: "unit",
    description: "Professional LED stage lighting for dramatic effect on your main stage",
  },
  {
    id: "led-wall",
    name: "LED Wall",
    pricePerUnit: 15000,
    minQty: 1,
    maxQty: 4,
    unit: "panel",
    description: "High-resolution LED display wall for live feeds, presentations, or branding",
  },
  {
    id: "flower-decor",
    name: "Flower Decoration",
    pricePerUnit: null, // variable
    minQty: 1,
    maxQty: 1,
    unit: "package",
    description: "Exquisite floral arrangements curated for your event theme and preferences",
    variableNote: "Price depends on event date, flower selection & scale. We'll send a personalised quote.",
  },
];

export const STANDARD_PACKAGE = {
  name: "Standard Package",
  price: 49999,
  currency: "₹",
  tagline: "Everything you need for a perfect event",
  features: [
    "Basic Decoration (Balloon, Draping & Table Setup)",
    "Sound System (DJ Console + 2 Speakers)",
    "Event Coordination (Dedicated Event Manager)",
    "Photography Support (4 Hours + 200 Edited Photos)",
    "Basic Lighting (Ambient & Accent Lighting)",
  ],
  popular: true,
};

export const PROCESS = [
  { step: "01", title: "Consultation", text: "We understand your vision, preferences, budget, and guest list to create a tailored event plan." },
  { step: "02", title: "Concept Design", text: "Our creative team develops mood boards, themes, and layouts aligned with your vision." },
  { step: "03", title: "Vendor Curation", text: "We handpick and coordinate the best vendors — caterers, decorators, photographers, and entertainers." },
  { step: "04", title: "Logistics Planning", text: "Detailed timelines, floor plans, and contingency plans are set to ensure nothing is left to chance." },
  { step: "05", title: "Event Day Execution", text: "Our team manages every detail on the day so you can enjoy the moment completely stress-free." },
  { step: "06", title: "Post-Event Support", text: "We handle wrap-up, vendor settlements, and deliver memories — albums, highlight reels, and more." },
];

export const WHY_VENDRA = [
  { icon: "Award", title: "8+ Years of Excellence", text: "Trusted by 350+ clients across India for exceptional event experiences." },
  { icon: "Users", title: "Dedicated Event Team", text: "A passionate team of planners, designers, and coordinators at your service." },
  { icon: "Shield", title: "Stress-Free Planning", text: "We manage every detail so you focus on celebrating, not coordinating." },
  { icon: "Sparkles", title: "Bespoke Designs", text: "Every event is one-of-a-kind — crafted to reflect your personality and vision." },
  { icon: "Clock", title: "On-Time Execution", text: "Meticulous timelines ensure your event runs perfectly from start to finish." },
  { icon: "Headphones", title: "24/7 Support", text: "Our team is reachable around the clock during your event planning journey." },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: "Priya & Arjun Sharma",
    event: "Wedding Reception · Mumbai",
    rating: 5,
    text: "Madras Events transformed our wedding into a fairy tale. Every detail was perfect — from the stunning floral decor to the grand entry that left our guests speechless. We couldn't have imagined a more magical day.",
    location: "Mumbai",
  },
  {
    name: "Rajesh Menon",
    event: "Corporate Annual Meet · Bangalore",
    rating: 5,
    text: "Our annual meet was executed flawlessly. Professional team, stunning stage setup, and the LED wall was a crowd favourite. Every colleague was impressed. Highly recommend Madras Events for corporate events.",
    location: "Bangalore",
  },
  {
    name: "Sneha Kapoor",
    event: "Birthday Celebration · Pune",
    rating: 5,
    text: "The 360 camera booth was the highlight of my daughter's 18th birthday! Guests are still sharing those videos. The whole event felt like something out of a magazine. Exceptional service throughout.",
    location: "Pune",
  },
  {
    name: "Aditya & Nisha Patel",
    event: "Engagement Ceremony · Ahmedabad",
    rating: 5,
    text: "From the initial consultation to the last dance, Madras Events was with us every step. The honeycomb lights and stage lighting created an ambiance we'll never forget. Pure elegance.",
    location: "Ahmedabad",
  },
  {
    name: "Meera Krishnamurthy",
    event: "Baby Shower · Chennai",
    rating: 5,
    text: "I was blown away by how beautifully they executed our baby shower theme. The instant photo booth was a huge hit with guests of all ages. Madras Events made this day unforgettable.",
    location: "Chennai",
  },
  {
    name: "TechVision Enterprises",
    event: "Product Launch · Hyderabad",
    rating: 5,
    text: "The product launch exceeded all our expectations. The LED wall, grand entry setup, and seamless coordination made our brand look world-class. We'll be booking Madras Events for every future event.",
    location: "Hyderabad",
  },
];

export const GALLERY_CATEGORIES = [
  { id: "all", label: "All Events" },
  { id: "wedding", label: "Weddings" },
  { id: "corporate", label: "Corporate" },
  { id: "birthday", label: "Birthdays" },
  { id: "entertainment", label: "Entertainment" },
  { id: "decor", label: "Decor" },
];

export const TEAM: TeamMember[] = [
  {
    name: "Venkat Rajan",
    role: "Founder & Creative Director",
    bio: "With 15+ years in luxury event management, Venkat's vision shapes every Madras Events event into an unforgettable experience.",
  },
  {
    name: "Ananya Krishnan",
    role: "Lead Event Designer",
    bio: "Ananya's eye for detail and passion for aesthetics transforms raw spaces into breathtaking event environments.",
  },
  {
    name: "Suresh Pillai",
    role: "Operations Head",
    bio: "Suresh ensures every event runs like clockwork — from vendor logistics to on-the-day execution.",
  },
  {
    name: "Deepika Nair",
    role: "Client Relations Manager",
    bio: "Deepika is your dedicated partner through the entire journey, ensuring your vision is heard and delivered perfectly.",
  },
];

export const VALUES = [
  {
    icon: "Heart",
    title: "Our Mission",
    text: "To create extraordinary events that become cherished memories — delivering flawless execution with genuine care for every client.",
  },
  {
    icon: "Eye",
    title: "Our Vision",
    text: "To be India's most trusted premium event company, known for innovation, elegance, and moments that last a lifetime.",
  },
  {
    icon: "Sparkles",
    title: "Our Values",
    text: "Passion over perfunctory, elegance over excess, and relationships over transactions. We celebrate your milestones as our own.",
  },
];

export const FAQS = [
  {
    q: "How far in advance should I book?",
    a: "We recommend booking at least 3–6 months in advance for weddings and large events, and 4–8 weeks for smaller events. Peak season (October–February) fills up quickly — reach out as early as possible.",
  },
  {
    q: "What is included in the Standard Package?",
    a: "The Standard Package (₹49,999) includes basic decoration, a sound system with DJ console and 2 speakers, a dedicated event coordinator, 4-hour photography support with 200 edited photos, and ambient & accent lighting.",
  },
  {
    q: "Can I customise the Standard Package?",
    a: "Absolutely! You can add on Honeycomb Lights, Stage Lights, LED Walls, and custom Flower Decoration to your Standard Package or build a fully custom package from scratch.",
  },
  {
    q: "What is the minimum order for Honeycomb and Stage Lights?",
    a: "Honeycomb Lights and Stage Lights require a minimum order of 2 units each. This ensures a balanced, impactful visual effect for your event.",
  },
  {
    q: "How is Flower Decoration priced?",
    a: "Flower Decoration pricing is not fixed as it depends on the event date, type of flowers, scale, and specific requirements. We provide a personalised quote after understanding your needs. Contact us for a consultation.",
  },
  {
    q: "Do you travel outside of your city?",
    a: "Yes! We manage events across India. Travel and accommodation charges may apply for outstation events. Contact us with your location for a detailed quote.",
  },
  {
    q: "What happens after I submit a booking?",
    a: "After submitting your booking, our team will contact you within 24 hours to confirm details, discuss your vision, and send you a formal proposal. A 25% advance secures your booking.",
  },
];

export const SOCIALS = [
  { icon: "Instagram", label: "Instagram", href: "#" },
  { icon: "Facebook", label: "Facebook", href: "#" },
  { icon: "Youtube", label: "YouTube", href: "#" },
  { icon: "Twitter", label: "Twitter", href: "#" },
];

export const CONTACT_INFO = {
  email: "hello@madrasevents.com",
  phone: "+91 98765 43210",
  phone2: "+91 91234 56789",
  location: "Chennai, Tamil Nadu, India",
  address: "No. 12, Nungambakkam High Road, Chennai - 600034",
  hours: "Mon – Sat: 10:00 AM – 7:00 PM",
};

export const FOOTER_SERVICES = [
  "Wedding Ceremonies",
  "Corporate Events",
  "Birthday Celebrations",
  "Entertainment Stalls",
  "Event Decoration",
  "360° Camera Booth",
];

export const FOOTER_NAV = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Pricing", href: "/pricing" },
  { label: "Gallery", href: "/gallery" },
  { label: "Contact", href: "/contact" },
];

export const EVENT_TYPES = [
  "Wedding",
  "Reception / Engagement",
  "Birthday Celebration",
  "Corporate Event",
  "Baby Shower",
  "Anniversary",
  "Product Launch",
  "Other",
];
