import type { Metadata } from "next";
import { Inter, Cormorant_Garamond } from "next/font/google";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { BookingProvider } from "@/components/ui/BookingContext";
import { BookingModal } from "@/components/ui/BookingModal";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  variable: "--font-cormorant",
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://madrasevents.com"),
  title: "Madras Events — Premium Event Management Company",
  description:
    "Madras Events crafts extraordinary events across India — weddings, corporate events, birthdays, and entertainment experiences. Book your dream event today.",
  keywords: [
    "event management", "wedding planner", "corporate events", "birthday party",
    "event decoration", "360 camera booth", "photo booth", "grand entry",
    "event company Chennai", "Madras Events",
  ],
  authors: [{ name: "Madras Events" }],
  creator: "Madras Events",
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://madrasevents.com",
    siteName: "Madras Events",
    title: "Madras Events — Premium Event Management Company",
    description:
      "Extraordinary events crafted with passion. Weddings, corporate events, birthdays & entertainment.",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "Madras Events" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Madras Events — Premium Event Management",
    description: "Extraordinary events crafted with passion.",
    images: ["/og.png"],
  },
  robots: { index: true, follow: true },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "EventManagementCompany",
  name: "Madras Events",
  url: "https://madrasevents.com",
  description: "Premium event management company specializing in weddings, corporate events, and celebrations.",
  address: {
    "@type": "PostalAddress",
    streetAddress: "No. 12, Nungambakkam High Road",
    addressLocality: "Chennai",
    addressRegion: "Tamil Nadu",
    postalCode: "600034",
    addressCountry: "IN",
  },
  contactPoint: {
    "@type": "ContactPoint",
    email: "hello@madrasevents.com",
    telephone: "+91-98765-43210",
    contactType: "customer service",
  },
  sameAs: [
    "https://instagram.com/madrasevents",
    "https://facebook.com/madrasevents",
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" className={`${inter.variable} ${cormorant.variable} antialiased`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className="min-h-screen font-sans" style={{ background: "var(--bg)", color: "var(--ink)" }}>
        <ThemeProvider>
          <BookingProvider>
            {children}
            <BookingModal />
          </BookingProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
