import { ServicesGrid } from "@/components/sections/ServicesGrid";
import { EntertainmentSection } from "@/components/sections/EntertainmentSection";
import { HomeCTA } from "@/components/sections/HomeCTA";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Loader } from "@/components/layout/Loader";
import { Cursor } from "@/components/layout/Cursor";
import { ScrollProgress } from "@/components/layout/ScrollProgress";
import { BackToTop } from "@/components/layout/BackToTop";

export const metadata = {
  title: "Services | Madras Events",
  description: "Explore our premium event management services, from wedding coordination to corporate events and exclusive entertainment stalls.",
};

export default function ServicesPage() {
  return (
    <>
      <Loader />
      <Cursor />
      <ScrollProgress />
      <BackToTop />
      <Navbar />

      <main>
        <ServicesGrid />
        <EntertainmentSection />
        <HomeCTA />
      </main>

      <Footer />
    </>
  );
}
