import { ContactForm } from "@/components/sections/ContactForm";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Loader } from "@/components/layout/Loader";
import { Cursor } from "@/components/layout/Cursor";
import { ScrollProgress } from "@/components/layout/ScrollProgress";
import { BackToTop } from "@/components/layout/BackToTop";

export const metadata = {
  title: "Contact Us | Madras Events",
  description: "Get in touch with Madras Events to start planning your perfect event today. We offer premium event management across India.",
};

export default function ContactPage() {
  return (
    <>
      <Loader />
      <Cursor />
      <ScrollProgress />
      <BackToTop />
      <Navbar />

      <main>
        <ContactForm />
      </main>

      <Footer />
    </>
  );
}
