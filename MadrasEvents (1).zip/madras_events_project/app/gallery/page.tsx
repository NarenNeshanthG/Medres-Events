import { GalleryGrid } from "@/components/sections/GalleryGrid";
import { HomeCTA } from "@/components/sections/HomeCTA";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Loader } from "@/components/layout/Loader";
import { Cursor } from "@/components/layout/Cursor";
import { ScrollProgress } from "@/components/layout/ScrollProgress";
import { BackToTop } from "@/components/layout/BackToTop";

export const metadata = {
  title: "Gallery | Madras Events",
  description: "Browse our portfolio of past events, weddings, and celebrations crafted by Madras Events.",
};

export default function GalleryPage() {
  return (
    <>
      <Loader />
      <Cursor />
      <ScrollProgress />
      <BackToTop />
      <Navbar />

      <main>
        <GalleryGrid />
        <HomeCTA />
      </main>

      <Footer />
    </>
  );
}
