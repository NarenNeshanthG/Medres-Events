import { HeroEvent } from "@/components/sections/HeroEvent";
import { StatsBar } from "@/components/sections/StatsBar";
import { ServicesPreview } from "@/components/sections/ServicesPreview";
import { WhyMadras } from "@/components/sections/WhyMadras";
import { TestimonialsCarousel } from "@/components/sections/TestimonialsCarousel";
import { HomeCTA } from "@/components/sections/HomeCTA";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Loader } from "@/components/layout/Loader";
import { Cursor } from "@/components/layout/Cursor";
import { ScrollProgress } from "@/components/layout/ScrollProgress";
import { BackToTop } from "@/components/layout/BackToTop";

export default function Home() {
  return (
    <>
      <Loader />
      <Cursor />
      <ScrollProgress />
      <BackToTop />
      <Navbar />

      <main>
        <HeroEvent />
        <StatsBar />
        <ServicesPreview />
        <WhyMadras />
        <TestimonialsCarousel />
        <HomeCTA />
      </main>

      <Footer />
    </>
  );
}
