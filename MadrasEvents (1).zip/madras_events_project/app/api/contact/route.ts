import { NextResponse } from "next/server";

/**
 * Placeholder contact form endpoint.
 * Replace with your real email / CRM integration (e.g. Resend, SendGrid, Airtable).
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, company, budget, details } = body;

    // Basic server-side validation
    if (!name || !email || !details) {
      return NextResponse.json({ error: "Name, email, and details are required." }, { status: 400 });
    }

    // TODO: Wire to real provider
    // e.g. await resend.emails.send({ from: '...', to: 'hello@webyon.com', subject: `New inquiry from ${name}`, ... })

    console.log("📬 Contact form submission:", { name, email, company, budget, details });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
