import { AboutHero } from "@/components/sections/AboutHero";
import { OurStory } from "@/components/sections/OurStory";
import { TeamGrid } from "@/components/sections/TeamGrid";
import { StatsBar } from "@/components/sections/StatsBar";
import { HomeCTA } from "@/components/sections/HomeCTA";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Loader } from "@/components/layout/Loader";
import { Cursor } from "@/components/layout/Cursor";
import { ScrollProgress } from "@/components/layout/ScrollProgress";
import { BackToTop } from "@/components/layout/BackToTop";

export const metadata = {
  title: "About Us | Madras Events",
  description: "Learn about Madras Events, our story, our process, and the passionate team behind your extraordinary events.",
};

export default function AboutPage() {
  return (
    <>
      <Loader />
      <Cursor />
      <ScrollProgress />
      <BackToTop />
      <Navbar />

      <main>
        <AboutHero />
        <OurStory />
        <StatsBar />
        <TeamGrid />
        <HomeCTA />
      </main>

      <Footer />
    </>
  );
}
