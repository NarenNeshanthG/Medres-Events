import { StandardPackage } from "@/components/sections/StandardPackage";
import { CustomPackageBuilder } from "@/components/sections/CustomPackageBuilder";
import { HomeCTA } from "@/components/sections/HomeCTA";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Loader } from "@/components/layout/Loader";
import { Cursor } from "@/components/layout/Cursor";
import { ScrollProgress } from "@/components/layout/ScrollProgress";
import { BackToTop } from "@/components/layout/BackToTop";

export const metadata = {
  title: "Pricing | Madras Events",
  description: "Transparent pricing for premium event management. Choose our standard package or build a custom experience.",
};

export default function PricingPage() {
  return (
    <>
      <Loader />
      <Cursor />
      <ScrollProgress />
      <BackToTop />
      <Navbar />

      <main>
        <StandardPackage />
        <CustomPackageBuilder />
        <HomeCTA />
      </main>

      <Footer />
    </>
  );
}
